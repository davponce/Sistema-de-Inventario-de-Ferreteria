package pruebasdesign;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author diego
 */
public class ControladorRegistroVentasResumen {
    private frmResumenInternal vista;
    private ModeloRegistroVentasResumen modelo;
    
    public ControladorRegistroVentasResumen(frmResumenInternal vista, ModeloRegistroVentasResumen modelo) {
        this.vista = vista;
        this.modelo = modelo;
        System.out.println("Controlador de Resumen de Ventas inicializado");
    }
    
    public void mostrar() {
        try {
            System.out.println("=== MOSTRANDO RESUMEN DE VENTAS ===");
            
            // Verificar si hay ventas
            if (modelo.obtenerPilaVentas().estaVacia()) {
                vista.mostrarMensaje("No hay ventas registradas", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Llamar al modelo para mostrar las ventas
            modelo.mostrarVentasEnTabla();
            
            // Calcular y mostrar estadísticas
            mostrarEstadisticas();
            
            // Mostrar estadísticas por origen
            modelo.mostrarEstadisticasPorOrigen();
            
        } catch (Exception e) {
            System.err.println("Error al mostrar resumen de ventas: " + e.getMessage());
            e.printStackTrace();
            vista.mostrarMensaje("Error al mostrar resumen: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para mostrar estadísticas de ventas
    private void mostrarEstadisticas() {
        try {
            Pila pilaVentas = modelo.obtenerPilaVentas();
            
            if (pilaVentas.estaVacia()) {
                return;
            }
            
            double totalVentas = 0.0;
            double totalContado = 0.0;
            double totalCredito = 0.0;
            int ventasContado = 0;
            int ventasCredito = 0;
            int productosVendidos = 0;
            int pagosCompletos = 0;
            int pagosPendientes = 0;
            
            Nodo aux = pilaVentas.getPila();
            while (aux != null) {
                Venta venta = (Venta) aux.getValor();
                if (venta != null) {
                    totalVentas += venta.getTotal();
                    productosVendidos += venta.getCantidad();
                    
                    if (venta.getTipoVenta() == 1) { // Contado
                        totalContado += venta.getTotal();
                        ventasContado++;
                    } else { // Crédito
                        totalCredito += venta.getTotal();
                        ventasCredito++;
                    }
                    
                    if (venta.isPagoCompleto()) {
                        pagosCompletos++;
                    } else {
                        pagosPendientes++;
                    }
                }
                aux = aux.getSiguiente();
            }
            
            int totalVentasCount = ventasContado + ventasCredito;
            
            // Mostrar resumen estadístico en consola
            String mensajeEstadisticas = 
                "=== RESUMEN ESTADÍSTICO ===\n" +
                "Total de ventas registradas: " + totalVentasCount + "\n" +
                "Monto total de ventas: $" + String.format("%.2f", totalVentas) + "\n" +
                "Ventas de contado: " + ventasContado + " ($" + String.format("%.2f", totalContado) + ")\n" +
                "Ventas a crédito: " + ventasCredito + " ($" + String.format("%.2f", totalCredito) + ")\n" +
                "Productos vendidos: " + productosVendidos + " unidades\n" +
                "Pagos completos: " + pagosCompletos + "\n" +
                "Pagos pendientes: " + pagosPendientes + "\n" +
                "Venta promedio: $" + String.format("%.2f", totalVentas / (totalVentasCount > 0 ? totalVentasCount : 1)) + "\n" +
                "=========================";
            
            System.out.println(mensajeEstadisticas);
            
        } catch (Exception e) {
            System.err.println("Error al calcular estadísticas: " + e.getMessage());
        }
    }
    
    // Método para filtrar ventas por tipo (0=Crédito, 1=Contado)
    public void filtrarPorTipo(int tipo) {
        try {
            modelo.filtrarVentasPorTipo(tipo);
        } catch (Exception e) {
            vista.mostrarMensaje("Error al filtrar ventas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para filtrar ventas por origen
    public void filtrarPorOrigen(String origen) {
        try {
            modelo.filtrarVentasPorOrigen(origen);
        } catch (Exception e) {
            vista.mostrarMensaje("Error al filtrar por origen: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para mostrar solo ventas de cotización
    public void mostrarSoloCotizaciones() {
        filtrarPorOrigen("Cotización");
    }
    
    // Método para mostrar solo ventas directas
    public void mostrarSoloVentasDirectas() {
        filtrarPorOrigen("Venta Directa");
    }
    
    // Método para mostrar todas las ventas
    public void mostrarTodas() {
        mostrar();
    }
    
    // Método para limpiar la tabla
    public void limpiarTabla() {
        DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"ID", "Origen", "Fecha", "Tipo Venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado Pago"}, 0
        );
        vista.jTable11.setModel(modelo);
    }
    
    // Método para mostrar error
    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(vista, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}