package pruebasdesign;
/**
 *
 * @author diego
 */
public class Cola {
     //Apuntador principal
    public Nodo cola;
    
    public Cola() {
        cola = null;
    }
    
    //Operacion para agregar al final de la Cola un nodo
    public void encolar(Object v){
        //Crear el nodo con el valor
        Nodo nuevo = new Nodo(v);
        //Para agregar, primero se valida si hay mas nodos o ninguno
        if(cola == null){
            cola = nuevo; //Se agrega el primer nodo a la cola
        } else { //Hay mas nodos y se agrega al final de la cola
            //Genera un apuntador auxiliar para recorrer la cola
            Nodo aux = cola;
            //Recorrer la lista, mediante el apuntador auxiliar
            while(aux.getSiguiente() != null){
                aux = aux.getSiguiente(); //avanza al siguiente nodo
            }//while
            aux.setSiguiente(nuevo); //Referencia el nuevo al ultimo nodo
        }//else
    }
    
    public String recorrerCola(){
        //Mostrar el contenido de la lista, siempre que no sea vacia
        //Genera un apuntador auxiliar para recorrer la Cola
        Nodo aux = cola;
        String valores = "";
        if(cola == null){
            valores = "La cola esta vacia";
        } else {
            valores = "Numeros en la cola: \n";
            //Recorrer la cola, mediante el apuntador auxiliar
            while(aux != null){
                valores += "Valor: " + aux.getValor() + "\n";
                aux = aux.getSiguiente(); //avanza al siguiente nodo
            }//while
        }//else
        return valores;
    }
    
    public String desencolar() {
        //Eliminar el primer elemento de la cola
        //Genera un apuntador auxiliar para recorrer la cola
        Nodo aux = cola;
        String valores = "";
        if(cola == null){
            valores = "La cola esta vacia";
        } else {
            //Se evalua si existen mas de un elemento en la cola
            if(aux.getSiguiente() == null){
                //Existe un solo elemento en la cola
                cola = null;
            } else {
                //Existen mas de un elemento en la cola y se elimina el primero
                cola = aux.getSiguiente();
            }//else2
            valores = "Primer elemento eliminado";
        }//else
        return valores;
    }

    public Nodo getCola() {
        return cola;
    }

    public void setCola(Nodo cola) {
        this.cola = cola;
    }
    
   public boolean estaVacia() {
        return cola == null;
    }
    
    public Nodo getFrente() {
        return cola;
    }
    
}
