package pruebasdesign;

/**
 *
 * @author Lenovo
 */
public class Cliente extends Persona {
    private String idCliente;
    private String tipoCliente;
    private String rfc;
    private String direccion;
    private int diasCredito;
    
     public Cliente() {
        super(); 
    }
        
    public Cliente(String idCliente, String tipoCliente, String rfc, String direccion, int diasCredito, String nombre, int genero, boolean activo, String numTelefonico, String edad) {
        super(nombre, genero, activo, numTelefonico, edad);
        this.idCliente = idCliente;
        this.tipoCliente = tipoCliente;
        this.rfc = rfc;
        this.direccion = direccion;
        this.diasCredito = diasCredito;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getTipoCliente() {
        return tipoCliente;
    }

    public void setTipoCliente(String tipoCliente) {
        this.tipoCliente = tipoCliente;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getDiasCredito() {
        return diasCredito;
    }

    public void setDiasCredito(int diasCredito) {
        this.diasCredito = diasCredito;
    }
    /*
     @Override
    public String toString() {
        return "Cliente{" +
                "ID='" + idCliente + '\'' +
                ", Nombre='" + nombre + '\'' +
                ", Tipo='" + tipoCliente + '\'' +
                ", RFC='" + rfc + '\'' +
                ", Dirección='" + direccion + '\'' +
                ", Días Crédito=" + diasCredito +
                ", Teléfono=" + numTelefonico +
                ", Edad=" + edad +
                ", Activo=" + activo +
                '}';
    }
    */
    @Override
public String toString() {
    return nombre + " (" + idCliente + ")"; // Solo muestra nombre y ID
}
}
