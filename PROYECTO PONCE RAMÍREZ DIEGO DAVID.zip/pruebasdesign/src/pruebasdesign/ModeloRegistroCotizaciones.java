package pruebasdesign;

import javax.swing.table.DefaultTableModel;

public class ModeloRegistroCotizaciones {
    private frmCotizacionesInternal vista;
    private Pila pilaCotizaciones;
    private Cotizacion cotizacion;
    
    public ModeloRegistroCotizaciones(frmCotizacionesInternal vista, Pila pilaCotizaciones, Cotizacion cotizacion) {
        this.vista = vista;
        this.pilaCotizaciones = pilaCotizaciones;
        this.cotizacion = cotizacion;
    }
    
    public void agregarCotizacion(Cotizacion nuevaCotizacion) {
        Nodo nuevoNodo = new Nodo(nuevaCotizacion);
        
        pilaCotizaciones.apilar(nuevoNodo);
        
        System.out.println("Cotización agregada al modelo: " + nuevaCotizacion.getId());
    }
    
    public void mostrarCotizaciones() {
        DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"ID", "Fecha", "Cliente", "Producto", "Cantidad", "Descuento", "Subtotal", "Total", "Tipo Venta", "Acción"}, 0
        ) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 9) {
                    return Object.class; 
                }
                return super.getColumnClass(columnIndex);
            }
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 9; 
            }
        };
        
        Nodo actual = pilaCotizaciones.getPila();
        while (actual != null) {
            Cotizacion c = (Cotizacion) actual.getValor();
            if (c != null && c.getCliente() != null && c.getProducto() != null) {
                modelo.addRow(new Object[]{
                    c.getId(),
                    c.getFecha() != null ? c.getFecha().toString() : "N/A",
                    c.getCliente().getNombre(),
                    c.getProducto().getDescripcion(),
                    c.getCantidad(),
                    String.format("%.0f%%", c.getDescuento() * 100),
                    String.format("$%.2f", c.getSubtotal()),
                    String.format("$%.2f", c.getTotal()),
                    c.getTipoVenta(),
                    "Convertir a Venta"
                });
            }
            actual = actual.getSiguiente();
        }
        
        vista.jTable1.setModel(modelo);
        
        System.out.println("Total de cotizaciones mostradas: " + pilaCotizaciones.tamaño());
    }
    
    public Cotizacion buscarCotizacion(String id) {
        Nodo actual = pilaCotizaciones.getPila();
        while (actual != null) {
            Cotizacion c = (Cotizacion) actual.getValor();
            if (c != null && c.getId().equals(id)) {
                return c;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }
    
    public void eliminarCotizacion(String id) {
        Object eliminado = pilaCotizaciones.eliminar(id);
        if (eliminado != null) {
            System.out.println("Cotización eliminada: " + id);
        } else {
            System.out.println("No se encontró la cotización con ID: " + id);
        }
    }
    
    public Cotizacion obtenerUltimaCotizacion() {
        if (pilaCotizaciones.getPila() != null) {
            Nodo primerNodo = pilaCotizaciones.getPila();
            if (primerNodo != null) {
                return (Cotizacion) primerNodo.getValor();
            }
        }
        return null;
    }
}