package pruebasdesign;
import java.time.LocalDateTime;
import java.util.List;
/**
 *
 * @author Lenovo
 */
public class Venta {
   private LocalDateTime fecha;
   private String id;
   private int tipoVenta;
   private int cantidad;
   private Cliente clientes;
   private Producto producto;
   private double descuento;
   private double subtotal;
   private double total;
   private boolean pagoCompleto;
   
   public Venta() {
        super(); 
    }

    public Venta(LocalDateTime fecha, String id, int tipoVenta, int cantidad, Cliente clientes, Producto producto, double descuento, double subtotal, double total, boolean pagoCompleto) {
        this.fecha = fecha;
        this.id = id;
        this.tipoVenta = tipoVenta;
        this.cantidad = cantidad;
        this.clientes = clientes;
        this.producto = producto;
        this.descuento = descuento;
        this.subtotal = subtotal;
        this.total = total;
        this.pagoCompleto = pagoCompleto;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getTipoVenta() {
        return tipoVenta;
    }

    public void setTipoVenta(int tipoVenta) {
        this.tipoVenta = tipoVenta;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Cliente getClientes() {
        return clientes;
    }

    public void setClientes(Cliente clientes) {
        this.clientes = clientes;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public boolean isPagoCompleto() {
        return pagoCompleto;
    }

    public void setPagoCompleto(boolean pagoCompleto) {
        this.pagoCompleto = pagoCompleto;
    }


}