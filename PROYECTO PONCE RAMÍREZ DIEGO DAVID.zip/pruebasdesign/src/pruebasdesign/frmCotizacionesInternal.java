package pruebasdesign;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DateEditor;
import javax.swing.JTable;
import javax.swing.SpinnerDateModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author Lenovo
 */
public class frmCotizacionesInternal extends javax.swing.JInternalFrame {

    /**
     * Creates new form frmCotizacionesInternal
     */
    private ControladorRegistroCotizaciones controlador;
    private JSpinner fechaSpinner;
    private Cola colaClientes;
    private Pila pilaProductos;
    
    
    public frmCotizacionesInternal(FrmCotizaciones cotizacion) {
        initComponents();
        inicializarComponentes();
        configurarTabla();
        // Cargar cotizaciones existentes al iniciar
        if (controlador != null) {
            controlador.mostrarCotizaciones();
        }
    }
    
    private void inicializarComponentes() {
        // Obtener instancia del gestor de datos
        GestorDatos gestor = GestorDatos.obtenerInstancia();
        this.colaClientes = gestor.getColaClientes();
        this.pilaProductos = gestor.getPilaProductos();
        
        // Inicializar controlador
        Pila pilaCotizaciones = gestor.getPilaCotizaciones();
        Cotizacion cotizacion = new Cotizacion();
        ModeloRegistroCotizaciones modelo = new ModeloRegistroCotizaciones(this, pilaCotizaciones, cotizacion);
        controlador = new ControladorRegistroCotizaciones(this, modelo);
        
        // Configurar componentes
        configurarSelectorFecha();
        cargarComboClientes();
        cargarComboProductos();
        configurarEtiquetas();
        configurarListeners();
        
        // Configurar propiedades del internal frame
        setClosable(true);
        setMaximizable(true);
        setIconifiable(true);
        setResizable(true);
        setTitle("Gestión de Cotizaciones");
        
        // Cambiar nombre de las pestañas
        jTabbedPane1.setTitleAt(0, "Nueva Cotización");
        jTabbedPane1.setTitleAt(1, "Historial");
    }
    
    private void configurarSelectorFecha() {
        // Crear selector de fecha
        SpinnerDateModel model = new SpinnerDateModel();
        fechaSpinner = new JSpinner(model);
        DateEditor editor = new DateEditor(fechaSpinner, "dd/MM/yyyy");
        fechaSpinner.setEditor(editor);
        fechaSpinner.setValue(new Date());
        
        // Agregar al panel de fecha
        jpFecha.setLayout(new java.awt.BorderLayout());
        jpFecha.add(fechaSpinner, java.awt.BorderLayout.CENTER);
    }
    
    private void cargarComboClientes() {
        jcbClientes.removeAllItems();
        if (colaClientes != null) {
            Nodo actual = colaClientes.getCola();
            while (actual != null) {
                Cliente c = (Cliente) actual.getValor();
                jcbClientes.addItem(c);
                actual = actual.getSiguiente();
            }
        }
    }
    
    private void cargarComboProductos() {
        jcbProducto.removeAllItems();
        if (pilaProductos != null) {
            Nodo actual = pilaProductos.getPila();
            while (actual != null) {
                Producto p = (Producto) actual.getValor();
                jcbProducto.addItem(p);
                actual = actual.getSiguiente();
            }
        }
    }
    
    public void actualizarComboBoxes() {
        cargarComboClientes();
        cargarComboProductos();
    }
    
    private void configurarEtiquetas() {
        // Configurar valores iniciales
        jsbCantidad.setMinimum(1);
        jsbCantidad.setMaximum(30);
        jsbCantidad.setValue(1);
        jlbCantidad.setText("Cantidad: " + jsbCantidad.getValue());
        jlbSubtotal.setText("$0.00");
        jlbIva.setText("$0.00");
        jlbTotal.setText("$0.00");
    }
    
    private void configurarListeners() {
        // Listeners para actualizar cálculos
        jcbProducto.addActionListener(e -> actualizarCalculos());
        jcbDescuento.addActionListener(e -> actualizarCalculos());
        jcbVenta.addActionListener(e -> actualizarCalculos());
        jsbCantidad.addAdjustmentListener(e -> {
            jlbCantidad.setText("Cantidad: " + jsbCantidad.getValue());
            actualizarCalculos();
        });
    }
    
    private void configurarTabla() {
        // Configurar modelo de tabla con columna de acción
        DefaultTableModel modelo = new DefaultTableModel(
            new Object[][]{},
            new String[]{
                "ID", "Fecha", "Cliente", "Producto", "Cantidad", "Descuento", "Subtotal", "Total", "Tipo Venta", "Acción"
            }
        ) {
            Class[] types = new Class[]{
                java.lang.String.class, java.lang.String.class, java.lang.String.class,
                java.lang.String.class, java.lang.Integer.class, java.lang.String.class,
                java.lang.String.class, java.lang.String.class, java.lang.String.class,
                java.lang.Object.class
            };
            boolean[] canEdit = new boolean[]{
                false, false, false, false, false, false, false, false, false, true
            };

            @Override
            public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }

            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        };
        
        jTable1.setModel(modelo);
        
        // Configurar renderizador y editor para la columna de acción
        jTable1.getColumn("Acción").setCellRenderer(new ButtonRenderer());
        jTable1.getColumn("Acción").setCellEditor(new ButtonEditor(new JCheckBox()));
        
        // Agregar listener para el doble click
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    convertirCotizacionAVenta();
                }
            }
        });
    }
    
    private void actualizarCalculos() {
        try {
            if (jcbProducto.getSelectedItem() != null) {
                Producto productoSeleccionado = (Producto) jcbProducto.getSelectedItem();
                double precioUnitario = productoSeleccionado.getPrecioCompra();
                int cantidad = jsbCantidad.getValue();
                
                // Verificar stock
                if (cantidad > productoSeleccionado.getStockActual()) {
                    mostrarMensaje("Stock insuficiente. Stock disponible: " + 
                        productoSeleccionado.getStockActual(), 
                        "Stock insuficiente", JOptionPane.WARNING_MESSAGE);
                    jsbCantidad.setValue(productoSeleccionado.getStockActual());
                    cantidad = productoSeleccionado.getStockActual();
                }
                
                // Calcular descuento
                double porcentajeDescuento = 0.0;
                switch(jcbDescuento.getSelectedIndex()) {
                    case 0: porcentajeDescuento = 0.00; break;
                    case 1: porcentajeDescuento = 0.05; break;
                    case 2: porcentajeDescuento = 0.15; break;
                    case 3: porcentajeDescuento = 0.20; break;
                    case 4: porcentajeDescuento = 0.50; break;
                }
                
                // Cálculos
                double subtotalSinDescuento = precioUnitario * cantidad;
                double montoDescuento = subtotalSinDescuento * porcentajeDescuento;
                double subtotal = subtotalSinDescuento - montoDescuento;
                double iva = subtotal * 0.16;
                double total = subtotal + iva;
                
                // Actualizar etiquetas
                jlbSubtotal.setText(String.format("$%.2f", subtotal));
                jlbIva.setText(String.format("$%.2f", iva));
                jlbTotal.setText(String.format("$%.2f", total));
            } else {
                jlbSubtotal.setText("$0.00");
                jlbIva.setText("$0.00");
                jlbTotal.setText("$0.00");
            }
        } catch (Exception e) {
            System.err.println("Error en actualizarCalculos: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Métodos para obtener datos del formulario
    public LocalDateTime getFechaSeleccionada() {
        Date fechaDate = (Date) fechaSpinner.getValue();
        return LocalDateTime.ofInstant(fechaDate.toInstant(), ZoneId.systemDefault());
    }
    
    public void setFecha(LocalDateTime fecha) {
        Date date = Date.from(fecha.atZone(ZoneId.systemDefault()).toInstant());
        fechaSpinner.setValue(date);
    }
    
    public Cliente getCliente() {
        return (Cliente) jcbClientes.getSelectedItem();
    }
    
    public Producto getProducto() {
        return (Producto) jcbProducto.getSelectedItem();
    }
    
    public double getPorcentajeDescuento() {
        switch(jcbDescuento.getSelectedIndex()) {
            case 0: return 0.00;
            case 1: return 0.05;
            case 2: return 0.15;
            case 3: return 0.20;
            case 4: return 0.50;
            default: return 0.00;
        }
    }
    
    public String getTipoVenta() {
        return (String) jcbVenta.getSelectedItem();
    }
    
    public int getCantidad() {
        return jsbCantidad.getValue();
    }
    
    public double getSubtotal() {
    try {
        String subtotal = jlbSubtotal.getText().trim();
        subtotal = subtotal.replace("$", "").replace(",", "");
        System.out.println("Texto subtotal: '" + subtotal + "'");
        double valor = Double.parseDouble(subtotal);
        System.out.println("Subtotal convertido: " + valor);
        return valor;
    } catch (Exception e) {
        System.err.println("Error en getSubtotal(): " + e.getMessage());
        return 0.0;
    }
}

public double getTotal() {
    try {
        String total = jlbTotal.getText().trim();
        total = total.replace("$", "").replace(",", "");
        System.out.println("Texto total: '" + total + "'");
        double valor = Double.parseDouble(total);
        System.out.println("Total convertido: " + valor);
        return valor;
    } catch (Exception e) {
        System.err.println("Error en getTotal(): " + e.getMessage());
        return 0.0;
    }
}
    public void mostrarMensaje(String mensaje, String titulo, int tipo) {
        javax.swing.JOptionPane.showMessageDialog(this, mensaje, titulo, tipo);
    }
    
    public void limpiarFormulario() {
        jcbClientes.setSelectedIndex(0);
        jcbProducto.setSelectedIndex(0);
        jcbDescuento.setSelectedIndex(0);
        jcbVenta.setSelectedIndex(0);
        jsbCantidad.setValue(1);
        fechaSpinner.setValue(new Date());
        actualizarCalculos();
    }
    
    // Método para actualizar la tabla después de registrar
    public void actualizarTablaCotizaciones() {
        if (controlador != null) {
            controlador.mostrarCotizaciones();
        }
    }
    
    // Método para obtener la cotización seleccionada
    public Cotizacion getCotizacionSeleccionada() {
        int fila = jTable1.getSelectedRow();
        if (fila >= 0) {
            String id = (String) jTable1.getValueAt(fila, 0);
            if (controlador != null) {
                return controlador.obtenerCotizacionPorId(id);
            }
        }
        return null;
    }
    
    // Método para convertir cotización a venta
    private void convertirCotizacionAVenta() {
        Cotizacion cotizacion = getCotizacionSeleccionada();
        if (cotizacion != null) {
            int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Convertir esta cotización en venta?\n\n" +
                "Cliente: " + cotizacion.getCliente().getNombre() + "\n" +
                "Producto: " + cotizacion.getProducto().getDescripcion() + "\n" +
                "Total: $" + cotizacion.getTotal(),
                "Confirmar conversión",
                JOptionPane.YES_NO_OPTION);
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                // Llamar al método del controlador
                controlador.convertirAVenta();
                
                // Actualizar tabla
                actualizarTablaCotizaciones();
            }
        } else {
            mostrarMensaje("Seleccione una cotización primero", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jsbCantidad = new javax.swing.JScrollBar();
        jpFecha = new javax.swing.JPanel();
        jlbCantidad = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jlbIva = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jlbTotal = new javax.swing.JLabel();
        jbnRegistrar = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jcbClientes = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jcbProducto = new javax.swing.JComboBox<>();
        jcbDescuento = new javax.swing.JComboBox<>();
        jcbVenta = new javax.swing.JComboBox<>();
        jlbSubtotal = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnSeleccionarUltima = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jLabel7.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel7.setText("Cotizaciones");

        jsbCantidad.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
        jsbCantidad.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                jsbCantidadAdjustmentValueChanged(evt);
            }
        });

        javax.swing.GroupLayout jpFechaLayout = new javax.swing.GroupLayout(jpFecha);
        jpFecha.setLayout(jpFechaLayout);
        jpFechaLayout.setHorizontalGroup(
            jpFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 277, Short.MAX_VALUE)
        );
        jpFechaLayout.setVerticalGroup(
            jpFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        jlbCantidad.setBackground(new java.awt.Color(0, 0, 0));
        jlbCantidad.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jlbCantidad.setText("Cantidad");

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel9.setText("Iva:");

        jlbIva.setBackground(new java.awt.Color(0, 0, 0));
        jlbIva.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jlbIva.setText("$0.0");

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel4.setText("Fecha ");

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel5.setText("Tipo de Venta");

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel6.setText("Subtotal:");

        jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        jLabel10.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel10.setText("Descuento");

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel8.setText("TOTAL:");

        jlbTotal.setBackground(new java.awt.Color(0, 0, 0));
        jlbTotal.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jlbTotal.setText("$0.0");

        jbnRegistrar.setBackground(new java.awt.Color(20, 33, 61));
        jbnRegistrar.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jbnRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        jbnRegistrar.setText("Registrar Cotizacion");
        jbnRegistrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnRegistrarActionPerformed(evt);
            }
        });

        jLabel22.setBackground(new java.awt.Color(0, 0, 0));
        jLabel22.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel22.setText("Cantidad");

        jLabel14.setBackground(new java.awt.Color(0, 0, 0));
        jLabel14.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel14.setText("Cliente:");

        jLabel15.setBackground(new java.awt.Color(0, 0, 0));
        jLabel15.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel15.setText("Producto:");

        jcbDescuento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0%", "5%", "15%", "20%", "50%" }));

        jcbVenta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Crédito", "Contado" }));

        jlbSubtotal.setBackground(new java.awt.Color(0, 0, 0));
        jlbSubtotal.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jlbSubtotal.setText("$0.0");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cotizacion.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(211, 211, 211)
                .addComponent(jLabel1)
                .addGap(51, 51, 51)
                .addComponent(jLabel7)
                .addContainerGap(376, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlbIva)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jbnRegistrar)
                            .addGap(104, 104, 104))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel9)
                            .addGap(272, 272, 272)))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(60, 60, 60)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel5)
                        .addComponent(jLabel4)
                        .addComponent(jpFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jcbVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel22)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jsbCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(26, 26, 26)
                            .addComponent(jlbCantidad)))
                    .addGap(147, 147, 147)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel10))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(89, 89, 89))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jlbSubtotal)
                                        .addGap(112, 112, 112)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlbTotal)
                                    .addComponent(jLabel8))
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jcbClientes, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jcbProducto, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel15))
                            .addGap(62, 62, 62)
                            .addComponent(jcbDescuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 245, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlbIva)
                .addGap(4, 4, 4)
                .addComponent(jbnRegistrar)
                .addGap(64, 64, 64))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(70, 70, 70)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10)
                        .addComponent(jLabel14))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jcbDescuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jcbClientes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(26, 26, 26)
                            .addComponent(jLabel15)
                            .addGap(18, 18, 18)
                            .addComponent(jcbProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel6)
                                .addComponent(jLabel8))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jlbSubtotal)
                                .addComponent(jlbTotal)))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jpFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jcbVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(43, 43, 43)
                            .addComponent(jLabel22)
                            .addGap(28, 28, 28)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jsbCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jlbCantidad))))
                    .addContainerGap(59, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Cotización", jPanel1);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        btnSeleccionarUltima.setBackground(new java.awt.Color(20, 33, 61));
        btnSeleccionarUltima.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnSeleccionarUltima.setForeground(new java.awt.Color(255, 255, 255));
        btnSeleccionarUltima.setText("Confirmar como venta la ultima cotizacion");
        btnSeleccionarUltima.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeleccionarUltimaActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cotizacion.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(117, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(btnSeleccionarUltima)
                .addGap(250, 250, 250))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(btnSeleccionarUltima)
                        .addGap(38, 38, 38))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Registro de Cotización", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 783, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(69, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jsbCantidadAdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_jsbCantidadAdjustmentValueChanged
        jlbCantidad.setText("Cantidad: " + jsbCantidad.getValue());
        actualizarCalculos();
    }//GEN-LAST:event_jsbCantidadAdjustmentValueChanged

    private void jbnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnRegistrarActionPerformed
        //registro.agregarVenta();
        if (controlador != null) {
            boolean exito = controlador.agregarCotizacion();
            if (exito) {
                // Mostrar en la pestaña de historial automáticamente
                jTabbedPane1.setSelectedIndex(1);
                // Actualizar la tabla
                actualizarTablaCotizaciones();
                // Limpiar formulario
                limpiarFormulario();
            }
        }
    }//GEN-LAST:event_jbnRegistrarActionPerformed

    private void btnSeleccionarUltimaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeleccionarUltimaActionPerformed
        // TODO add your handling code here:// Seleccionar la última cotización
        if (jTable1.getRowCount() > 0) {
            int ultimaFila = jTable1.getRowCount() - 1;
            jTable1.setRowSelectionInterval(ultimaFila, ultimaFila);
            jTable1.scrollRectToVisible(jTable1.getCellRect(ultimaFila, 0, true));
            convertirCotizacionAVenta();
        } else {
            mostrarMensaje("No hay cotizaciones registradas", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }                                                    

    // Clases internas para el botón en la tabla
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText("Convertir a Venta");
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private String label;
        private boolean isPushed;
        private int selectedRow;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    // Cuando se presiona el botón, convertir la cotización
                    jTable1.setRowSelectionInterval(selectedRow, selectedRow);
                    convertirCotizacionAVenta();
                }
            });
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            label = "Convertir a Venta";
            button.setText(label);
            isPushed = true;
            selectedRow = row;
            return button;
        }
        
        @Override
        public Object getCellEditorValue() {
            if (isPushed) {
                // El botón ya manejó la acción en el ActionListener
            }
            isPushed = false;
            return label;
        }
        
        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }//GEN-LAST:event_btnSeleccionarUltimaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSeleccionarUltima;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    public static javax.swing.JTable jTable1;
    private javax.swing.JButton jbnRegistrar;
    public javax.swing.JComboBox<Cliente> jcbClientes;
    public javax.swing.JComboBox<String> jcbDescuento;
    public javax.swing.JComboBox<Producto> jcbProducto;
    public javax.swing.JComboBox<String> jcbVenta;
    private javax.swing.JLabel jlbCantidad;
    private javax.swing.JLabel jlbIva;
    public javax.swing.JLabel jlbSubtotal;
    public javax.swing.JLabel jlbTotal;
    private javax.swing.JPanel jpFecha;
    public javax.swing.JScrollBar jsbCantidad;
    // End of variables declaration//GEN-END:variables
}
