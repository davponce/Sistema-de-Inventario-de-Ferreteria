
package pruebasdesign;
/**
 *
 * @author diego
 */
public class ModeloLogin {
 private Usuario[] usuarios;
 
    public ModeloLogin(Usuario[] usuarios) {
        this.usuarios = usuarios;
    }
    
    public boolean validarSesion(String usuario, String contrasena) {
        if (usuario == null || contrasena == null || 
            usuario.trim().isEmpty() || contrasena.trim().isEmpty()) {
            return false;
        }
        for (Usuario usua : usuarios) {
            if (usua != null) {
                if (usuario.equals(usua.getIdUsuario()) && 
                    contrasena.equals(usua.getPassword())) {
                    return true;
                }
            }
        }
        return false;
    }
}
