package pruebasdesign;

import java.time.LocalDateTime;

public class Cotizacion {
    private String id;
    private LocalDateTime fecha;
    private Cliente cliente;
    private Producto producto;
    private int cantidad;
    private double descuento;
    private double subtotal;
    private double total;
    private String tipoVenta;
    
    // Constructor vacío
    public Cotizacion() {}
    
    // Constructor completo
    public Cotizacion(String id, LocalDateTime fecha, Cliente cliente, Producto producto, 
                     int cantidad, double descuento, double subtotal, double total, String tipoVenta) {
        this.id = id;
        this.fecha = fecha;
        this.cliente = cliente;
        this.producto = producto;
        this.cantidad = cantidad;
        this.descuento = descuento;
        this.subtotal = subtotal;
        this.total = total;
        this.tipoVenta = tipoVenta;
    }
    
    // Getters y setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }
    
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    
    public Producto getProducto() { return producto; }
    public void setProducto(Producto producto) { this.producto = producto; }
    
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    
    public double getDescuento() { return descuento; }
    public void setDescuento(double descuento) { this.descuento = descuento; }
    
    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
    
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
    
    public String getTipoVenta() { return tipoVenta; }
    public void setTipoVenta(String tipoVenta) { this.tipoVenta = tipoVenta; }
    
    @Override
public String toString() {
    return "Cotizacion{" +
            "id='" + id + '\'' +
            ", fecha=" + fecha +
            ", cliente=" + (cliente != null ? cliente.getNombre() : "null") +
            ", producto=" + (producto != null ? producto.getDescripcion() : "null") +
            ", cantidad=" + cantidad +
            ", descuento=" + descuento +
            ", subtotal=" + subtotal +
            ", total=" + total +
            ", tipoVenta='" + tipoVenta + '\'' +
            '}';
}
}