package pruebasdesign;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * Controlador para gestionar el registro de clientes
 * @author diego
 */
public class ControladorRegistroClientes {
    frmClientesInternal frmClientes;
    ModeloRegistroClientes registroClientes;
    Cola colaClientes;
    private String idClienteModificar;
    
    public ControladorRegistroClientes(frmClientesInternal frmClientes, ModeloRegistroClientes registroClientes) {
        this.frmClientes = frmClientes;
        this.registroClientes = registroClientes;
        this.colaClientes = new Cola(); 
    }
    
    public void agregar(){
        String id = frmClientes.getId();
        String tipo = frmClientes.getTipo();
        String rfc = frmClientes.getRFC();
        String direccion = frmClientes.getDireccion();
        String credito = frmClientes.getCredito();
        String nombre = frmClientes.getNombre();
        int genero = frmClientes.getGenero();
        boolean activo = frmClientes.getActivo();
        String telefono = frmClientes.getTelefono();
        String edad = frmClientes.getEdad();
       
        if(id.isEmpty() || tipo.isEmpty() || rfc.isEmpty() || 
           direccion.isEmpty() || credito.isEmpty() || nombre.isEmpty() || 
           telefono.isEmpty() || edad.isEmpty()){
            mostrarError("Faltan campos por llenar");
            return;
        }
        
        if(genero == 0){
            mostrarError("Debe seleccionar un género");
            return;
        }
        
        try {
            int creditoInt = Integer.parseInt(credito);
            
            if(creditoInt < 0){
                mostrarError("Los días de crédito no pueden ser negativos");
                return;
            }
            registroClientes.agregarCliente(id, tipo, rfc, direccion, creditoInt, 
                                           nombre, genero, activo, telefono, edad);
            
            JOptionPane.showMessageDialog(null, "Cliente agregado exitosamente", 
                                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (NumberFormatException e) {
            mostrarError("Error en campos numéricos: Edad, Teléfono o Días de Crédito deben ser números válidos");
        }
    }
    
 public void limpiar(){
    frmClientes.limpiarCampos();
    frmClientes.jtfId.setEditable(true);
    idClienteModificar = null;
}
 
    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
public void mostrar(){
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID", "Nombre", "Dirección", "Teléfono", "Días crédito"}, 0
    );
    
    frmClientes.jTable1.setModel(modelo);
    
    Cola colaClientes = registroClientes.obtenerColaClientes();
    
    if(colaClientes != null && !colaClientes.estaVacia()) {
        Nodo aux = colaClientes.getFrente();
        
        while (aux != null) {
            Cliente l = (Cliente) aux.getValor();
            modelo.addRow(new Object[]{
                l.getIdCliente(),
                l.getNombre(),
                l.getDireccion(),
                l.getNumTelefonico(),
                l.getDiasCredito()
            });
            
            aux = aux.getSiguiente();
        }
    }
}

    public void buscar(){
    String id = frmClientes.buscar();
    
    if(id.isEmpty()){
        mostrarError("Ingrese un ID para buscar");
        return;
    }
    
    Cliente clienteEncontrado = registroClientes.buscar(id);
    
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID", "Nombre", "Dirección", "Teléfono", "Días crédito"}, 0
    );
    
    if(clienteEncontrado != null){
        modelo.addRow(new Object[]{
            clienteEncontrado.getIdCliente(),
            clienteEncontrado.getNombre(),
            clienteEncontrado.getDireccion(),
            clienteEncontrado.getNumTelefonico(),
            clienteEncontrado.getDiasCredito()
        });
        
        JOptionPane.showMessageDialog(null, "Cliente encontrado", 
                                    "Búsqueda exitosa", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(null, "Cliente con ID " + id + " no encontrado", 
                                    "Búsqueda", JOptionPane.WARNING_MESSAGE);
    }
    
    frmClientes.jTable1.setModel(modelo);
}
    
    public void limpiarTablaClientes(){
    frmClientes.limpiarTabla();
}
    
    public void eliminar(){
    String id = frmClientes.buscar();
    
    if(id.isEmpty()){
        mostrarError("Ingrese un ID para eliminar");
        return;
    }
    
    Cliente clienteEncontrado = registroClientes.eliminar(id);
    
    JOptionPane.showMessageDialog(null, "Cliente eliminado", 
                                    "Búsqueda exitosa", JOptionPane.INFORMATION_MESSAGE);
    
    frmClientes.limpiarTabla();
    
    }
    
   public void buscarModificar(){
    String id = JOptionPane.showInputDialog("Ingrese el ID del cliente a modificar:");
    
    if(id == null || id.isEmpty()){
        mostrarError("Ingrese un ID para buscar");
        return;
    }
    
    Cliente clienteEncontrado = registroClientes.buscar(id);
    
    if(clienteEncontrado != null){
        idClienteModificar = id;
        frmClientes.jtfId.setEditable(false);

        frmClientes.jtfNombre.setText(clienteEncontrado.getNombre());
        frmClientes.jcbActivo.setSelected(clienteEncontrado.isActivo());
        frmClientes.jtfTelefono.setText(clienteEncontrado.getNumTelefonico());
        frmClientes.jtfEdad.setText(clienteEncontrado.getEdad());
        frmClientes.jtfId.setText(clienteEncontrado.getIdCliente());
        frmClientes.jtfTipoCliente.setText(clienteEncontrado.getTipoCliente());
        frmClientes.jtfRFC.setText(clienteEncontrado.getRfc());
        frmClientes.jtfDireccion.setText(clienteEncontrado.getDireccion());
        frmClientes.jtfCredito.setText(String.valueOf(clienteEncontrado.getDiasCredito()));
        
        int genero = clienteEncontrado.getGenero();
        boolean masculino = (genero == 1);
        boolean femenino = (genero == 2);
        frmClientes.jrbMasculino.setSelected(masculino);
        frmClientes.jrbFemenino.setSelected(femenino);
        
        JOptionPane.showMessageDialog(null, "Cliente encontrado. Modifique los campos necesarios.");
    } else {
        mostrarError("Cliente no encontrado");
        idClienteModificar = null; 
    }
}
    
    public void modificar(){
    if (idClienteModificar == null || idClienteModificar.isEmpty()) {
        mostrarError("Debe buscar un cliente primero usando 'Buscar para modificar'");
        return;
    }
    
    String tipo = frmClientes.getTipo();
    String rfc = frmClientes.getRFC();
    String direccion = frmClientes.getDireccion();
    String credito = frmClientes.getCredito();
    String nombre = frmClientes.getNombre();
    int genero = frmClientes.getGenero();
    boolean activo = frmClientes.getActivo();
    String telefono = frmClientes.getTelefono();
    String edad = frmClientes.getEdad();
   
    if(tipo.isEmpty() || rfc.isEmpty() || direccion.isEmpty() || 
       credito.isEmpty() || nombre.isEmpty() || telefono.isEmpty() || edad.isEmpty()){
        mostrarError("Faltan campos por llenar");
        return;
    }
    
    if(genero == 0){
        mostrarError("Debe seleccionar un género");
        return;
    }
    
    try {
        int creditoInt = Integer.parseInt(credito);
        
        if(creditoInt < 0){
            mostrarError("Los días de crédito no pueden ser negativos");
            return;
        }
        
        registroClientes.modificarCliente(idClienteModificar, tipo, rfc, direccion, 
                                        creditoInt, nombre, genero, activo, 
                                        telefono, edad);
        
        JOptionPane.showMessageDialog(null, "Cliente modificado exitosamente", 
                                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
        
        idClienteModificar = null;
        
    } catch (NumberFormatException e) {
        mostrarError("Error en campos numéricos: Edad, Teléfono o Días de Crédito deben ser números válidos");
    }
}
    
    public void mostrarClientesSinPagoCompleto() {
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID Cliente", "Nombre", "Teléfono", "ID Venta", "Total Pendiente"}, 0
    );
    
    frmClientes.jTable2.setModel(modelo);
    
    GestorDatos gestor = GestorDatos.obtenerInstancia();
    Pila pilaVentas = gestor.getPilaVentas();
    
    if(pilaVentas != null && !pilaVentas.estaVacia()) {
        Nodo aux = pilaVentas.getPila();
        
        while (aux != null) {
            Venta venta = (Venta) aux.getValor();
            
            // Verificar si el pago NO está completo
            if(!venta.isPagoCompleto()) {
                Cliente cliente = venta.getClientes();
                
                if(cliente != null) {
                    modelo.addRow(new Object[]{
                        cliente.getIdCliente(),
                        cliente.getNombre(),
                        cliente.getNumTelefonico(),
                        venta.getId(),
                        "$" + String.format("%.2f", venta.getTotal())
                    });
                }
            }
            
            aux = aux.getSiguiente();
        }
        
        if(modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, 
                "No hay clientes con pagos pendientes", 
                "Información", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, 
            "No hay ventas registradas", 
            "Información", 
            JOptionPane.INFORMATION_MESSAGE);
    }
}
}