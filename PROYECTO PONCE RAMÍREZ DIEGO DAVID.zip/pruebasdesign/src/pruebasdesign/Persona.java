package pruebasdesign;

/**
 *
 * @author Lenovo
 */
public class Persona {
    protected String nombre;
    protected int genero;
    protected boolean activo;
    protected String numTelefonico;
    protected String edad;
    
    public Persona() {
    }

    public Persona(String nombre, int genero, boolean activo, String numTelefonico, String edad) {
        this.nombre = nombre;
        this.genero = genero;
        this.activo = activo;
        this.numTelefonico = numTelefonico;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getGenero() {
        return genero;
    }

    public void setGenero(int genero) {
        this.genero = genero;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public String getNumTelefonico() {
        return numTelefonico;
    }

    public void setNumTelefonico(String numTelefonico) {
        this.numTelefonico = numTelefonico;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }
   
}
