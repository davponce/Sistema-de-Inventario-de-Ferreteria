package pruebasdesign;

import java.time.LocalDateTime;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ControladorRegistroCotizaciones {
    private frmCotizacionesInternal vista;
    private ModeloRegistroCotizaciones modelo;
    
    public ControladorRegistroCotizaciones(frmCotizacionesInternal vista, ModeloRegistroCotizaciones modelo) {
        this.vista = vista;
        this.modelo = modelo;
        System.out.println("Controlador inicializado");
    }
    
    public boolean agregarCotizacion() {
        try {
            System.out.println("=== INICIANDO REGISTRO DE COTIZACIÓN ===");
            
            // Validar campos
            if (vista.getCliente() == null) {
                vista.mostrarMensaje("Seleccione un cliente", "Error", JOptionPane.ERROR_MESSAGE);
                System.out.println("Error: Cliente no seleccionado");
                return false;
            }
            
            if (vista.getProducto() == null) {
                vista.mostrarMensaje("Seleccione un producto", "Error", JOptionPane.ERROR_MESSAGE);
                System.out.println("Error: Producto no seleccionado");
                return false;
            }
            
            Cliente cliente = vista.getCliente();
            Producto producto = vista.getProducto();
            int cantidad = vista.getCantidad();
            
            System.out.println("Cliente seleccionado: " + cliente.getNombre());
            System.out.println("Producto seleccionado: " + producto.getDescripcion());
            System.out.println("Cantidad: " + cantidad);
            System.out.println("Stock disponible: " + producto.getStockActual());
            
            if (cantidad > producto.getStockActual()) {
                vista.mostrarMensaje(
                    "Stock insuficiente para " + producto.getDescripcion() + 
                    "\nStock disponible: " + producto.getStockActual() + 
                    "\nCantidad solicitada: " + cantidad,
                    "Stock insuficiente", 
                    JOptionPane.ERROR_MESSAGE
                );
                return false;
            }
            
            // Generar ID único
            String id = "COT-" + System.currentTimeMillis();
            System.out.println("ID generado: " + id);
            
            // Obtener tipo de venta
            String tipoVenta = vista.getTipoVenta();
            System.out.println("Tipo de venta: " + tipoVenta);
            
            // Obtener valores numéricos
            double subtotal = vista.getSubtotal();
            double total = vista.getTotal();
            double descuento = vista.getPorcentajeDescuento();
            
            System.out.println("Subtotal: $" + subtotal);
            System.out.println("Total: $" + total);
            System.out.println("Descuento: " + (descuento * 100) + "%");
            
            // Crear nueva cotización
            Cotizacion nuevaCotizacion = new Cotizacion();
            nuevaCotizacion.setId(id);
            nuevaCotizacion.setFecha(vista.getFechaSeleccionada());
            nuevaCotizacion.setCliente(cliente);
            nuevaCotizacion.setProducto(producto);
            nuevaCotizacion.setCantidad(cantidad);
            nuevaCotizacion.setDescuento(descuento);
            nuevaCotizacion.setSubtotal(subtotal);
            nuevaCotizacion.setTotal(total);
            nuevaCotizacion.setTipoVenta(tipoVenta);
            
            System.out.println("Cotización creada exitosamente");
            
            // Agregar al modelo
            modelo.agregarCotizacion(nuevaCotizacion);
            System.out.println("Cotización agregada al modelo");
            
             String mensajeStock = "";
            if (producto.getStockActual() < cantidad + 5) {
            mensajeStock = "\n⚠️ Advertencia: Stock bajo para este producto";
            }
            
            // Mostrar mensaje de éxito
            vista.mostrarMensaje(
                "✓ Cotización generada exitosamente\n" +
                "ID: " + id + "\n" +
                "Cliente: " + cliente.getNombre() + "\n" +
                "Producto: " + producto.getDescripcion() + "\n" +
                "Cantidad: " + cantidad + "\n" +
                "Total: $" + String.format("%.2f", total),
                "Éxito", 
                JOptionPane.INFORMATION_MESSAGE
            );
            
            System.out.println("=== REGISTRO DE COTIZACIÓN COMPLETADO ===");
            return true;
            
        } catch (Exception e) {
            System.err.println("=== ERROR EN AGREGAR COTIZACIÓN ===");
            System.err.println("Mensaje: " + e.getMessage());
            System.err.println("Causa: " + e.getCause());
            e.printStackTrace();
            System.err.println("===================================");
            
            vista.mostrarMensaje("Error al generar cotización: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public void mostrarCotizaciones() {
        try {
            modelo.mostrarCotizaciones();
        } catch (Exception e) {
            System.err.println("Error al mostrar cotizaciones: " + e.getMessage());
            e.printStackTrace();
            vista.mostrarMensaje("Error al mostrar cotizaciones: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public Cotizacion buscarCotizacion(String criterio) {
        try {
            return modelo.buscarCotizacion(criterio);
        } catch (Exception e) {
            System.err.println("Error al buscar cotización: " + e.getMessage());
            vista.mostrarMensaje("Error al buscar cotización: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    
    // Método para obtener cotización por ID
    public Cotizacion obtenerCotizacionPorId(String id) {
        return modelo.buscarCotizacion(id);
    }
    
    public void eliminarCotizacion() {
        try {
            int filaSeleccionada = vista.jTable1.getSelectedRow();
            if (filaSeleccionada >= 0) {
                String id = (String) vista.jTable1.getValueAt(filaSeleccionada, 0);
                
                int confirmacion = JOptionPane.showConfirmDialog(vista,
                    "¿Está seguro de eliminar la cotización con ID: " + id + "?",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION);
                
                if (confirmacion == JOptionPane.YES_OPTION) {
                    modelo.eliminarCotizacion(id);
                    mostrarCotizaciones();
                    vista.mostrarMensaje("Cotización eliminada exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                vista.mostrarMensaje("Seleccione una cotización para eliminar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            System.err.println("Error al eliminar cotización: " + e.getMessage());
            e.printStackTrace();
            vista.mostrarMensaje("Error al eliminar cotización: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para convertir cotización a venta
    public void convertirAVenta() {
        try {
            System.out.println("Iniciando conversión a venta...");
            
            int filaSeleccionada = vista.jTable1.getSelectedRow();
            if (filaSeleccionada >= 0) {
                String id = (String) vista.jTable1.getValueAt(filaSeleccionada, 0);
                System.out.println("ID de cotización seleccionada: " + id);
                
                // Buscar la cotización completa
                Cotizacion cotizacion = modelo.buscarCotizacion(id);
                if (cotizacion != null) {
                    System.out.println("Cotización encontrada: " + cotizacion);
                    
                    // Verificar stock antes de convertir
                    Producto producto = cotizacion.getProducto();
                    int cantidad = cotizacion.getCantidad();
                    
                    System.out.println("Verificando stock para conversión...");
                    System.out.println("Producto: " + producto.getDescripcion());
                    System.out.println("Stock actual: " + producto.getStockActual());
                    System.out.println("Cantidad requerida: " + cantidad);
                    
                    if (cantidad > producto.getStockActual()) {
                        vista.mostrarMensaje(
                            "No se puede convertir a venta. Stock insuficiente.\n" +
                            "Producto: " + producto.getDescripcion() + "\n" +
                            "Stock disponible: " + producto.getStockActual() + "\n" +
                            "Cantidad requerida: " + cantidad,
                            "Stock insuficiente",
                            JOptionPane.ERROR_MESSAGE
                        );
                        return;
                    }
                    
                    int opcionPago = JOptionPane.showConfirmDialog(vista,
                        "¿El cliente realizará el pago completo ahora?",
                        "Confirmar pago",
                        JOptionPane.YES_NO_OPTION);
                    
                    boolean pagoCompleto = (opcionPago == JOptionPane.YES_OPTION);
                    System.out.println("Pago completo: " + pagoCompleto);
                    
                    int tipoVentaNumero = cotizacion.getTipoVenta().equals("Contado") ? 1 : 0;
                    System.out.println("Tipo de venta numérico: " + tipoVentaNumero);
                    
                    Venta nuevaVenta = new Venta();
                    nuevaVenta.setFecha(LocalDateTime.now());
                    nuevaVenta.setId("VEN-" + System.currentTimeMillis());
                    nuevaVenta.setTipoVenta(tipoVentaNumero);
                    nuevaVenta.setCantidad(cantidad);
                    nuevaVenta.setClientes(cotizacion.getCliente());
                    nuevaVenta.setProducto(producto);
                    nuevaVenta.setDescuento(cotizacion.getDescuento());
                    nuevaVenta.setSubtotal(cotizacion.getSubtotal());
                    nuevaVenta.setTotal(cotizacion.getTotal());
                    nuevaVenta.setPagoCompleto(pagoCompleto);
                    
                    System.out.println("Venta creada: " + nuevaVenta.getId());
                    
                    GestorDatos gestor = GestorDatos.obtenerInstancia();
                    Nodo nuevoNodo = new Nodo(nuevaVenta);
                    gestor.getPilaVentas().apilar(nuevoNodo);
                    
                    boolean stockReducido = producto.reducirStock(cantidad);
                    if (stockReducido) {
                        System.out.println("Stock reducido para venta. Nuevo stock: " + producto.getStockActual());
                    }
                    
                    int confirmacion = JOptionPane.showConfirmDialog(vista,
                        "¿Desea eliminar la cotización después de convertirla en venta?",
                        "Eliminar cotización",
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirmacion == JOptionPane.YES_OPTION) {
                        modelo.eliminarCotizacion(id);
                        System.out.println("Cotización eliminada después de conversión");
                    }
                    
                    String mensajeResumen = 
                        "✓ VENTA REGISTRADA EXITOSAMENTE\n\n" +
                        "ID Venta: " + nuevaVenta.getId() + "\n" +
                        "Cliente: " + cotizacion.getCliente().getNombre() + "\n" +
                        "Producto: " + producto.getDescripcion() + "\n" +
                        "Cantidad: " + cantidad + "\n" +
                        "Descuento: " + String.format("%.0f%%", cotizacion.getDescuento() * 100) + "\n" +
                        "Subtotal: $" + String.format("%.2f", cotizacion.getSubtotal()) + "\n" +
                        "IVA: $" + String.format("%.2f", cotizacion.getTotal() - cotizacion.getSubtotal()) + "\n" +
                        "TOTAL: $" + String.format("%.2f", cotizacion.getTotal()) + "\n" +
                        "Tipo de Venta: " + cotizacion.getTipoVenta() + "\n" +
                        "Pago completo: " + (pagoCompleto ? "Sí" : "No") + "\n" +
                        "Fecha: " + nuevaVenta.getFecha().toString();
                    
                    vista.mostrarMensaje(mensajeResumen, "Venta Registrada", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("Conversión a venta completada exitosamente");
                    
                } else {
                    System.out.println("Cotización no encontrada con ID: " + id);
                    vista.mostrarMensaje("No se encontró la cotización con ID: " + id, "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                System.out.println("No se seleccionó ninguna fila");
                vista.mostrarMensaje("Seleccione una cotización para convertir en venta", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            System.err.println("ERROR DETALLADO en convertirAVenta:");
            e.printStackTrace();
            vista.mostrarMensaje("Error al convertir a venta: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}