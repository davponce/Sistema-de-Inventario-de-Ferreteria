
package pruebasdesign;

import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lenovo
 */
public class frmResumenInternal extends javax.swing.JInternalFrame {

    ControladorRegistroVentasResumen controladorResumen;
    ModeloRegistroVentasResumen modeloResumen;
    
    public frmResumenInternal() {
        initComponents();
        inicializarComponentes();
    }
    
    private void inicializarComponentes() {
        // Obtener instancia del gestor de datos
        GestorDatos gestor = GestorDatos.obtenerInstancia();
        
        // Inicializar modelo y controlador para resumen
        Pila pilaVentas = gestor.getPilaVentas();
        Venta venta = new Venta();
        modeloResumen = new ModeloRegistroVentasResumen(this, pilaVentas, venta);
        controladorResumen = new ControladorRegistroVentasResumen(this, modeloResumen);
        
        // Configurar propiedades del internal frame
        setClosable(true);
        setMaximizable(true);
        setIconifiable(true);
        setResizable(true);
        setTitle("Resumen de Ventas");
        
        System.out.println("Formulario de Resumen inicializado. Ventas disponibles: " + pilaVentas.tamaño());
    }
    
    // Método para mostrar mensajes
    public void mostrarMensaje(String mensaje, String titulo, int tipo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, tipo);
    }
    
    // Método para limpiar la tabla
    public void limpiarTabla() {
        DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"ID", "Fecha", "Tipo Venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado Pago"}, 0
        );
        jTable11.setModel(modelo);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable11 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        Cotizaciones = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        jTable11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable11.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jTable11.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Fecha", "Tipo de venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado de pago"
            }
        ));
        jTable11.setToolTipText("");
        jScrollPane1.setViewportView(jTable11);

        jButton1.setBackground(new java.awt.Color(20, 33, 61));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Mostar Resumen");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(20, 33, 61));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Limpiar");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(20, 33, 61));
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Solo Pago de Contado");
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(20, 33, 61));
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Solo Pago a Credito");
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        Cotizaciones.setBackground(new java.awt.Color(20, 33, 61));
        Cotizaciones.setForeground(new java.awt.Color(255, 255, 255));
        Cotizaciones.setText("Solo Cotizaciones");
        Cotizaciones.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Cotizaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CotizacionesActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(20, 33, 61));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Solo Ventas");
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 925, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4)
                        .addGap(19, 19, 19)
                        .addComponent(Cotizaciones)
                        .addGap(18, 18, 18)
                        .addComponent(jButton5)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(Cotizaciones)
                    .addComponent(jButton5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
if (controladorResumen != null) {
            controladorResumen.mostrar();
        } else {
            mostrarMensaje("Controlador no inicializado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if (controladorResumen != null) {
            controladorResumen.limpiarTabla();
            mostrarMensaje("Tabla limpiada", "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        if (controladorResumen != null) {
            controladorResumen.filtrarPorTipo(1); // 1 = Contado
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        if (controladorResumen != null) {
            controladorResumen.filtrarPorTipo(0); // 1 = Contado
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void CotizacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CotizacionesActionPerformed
        // TODO add your handling code here:
        if (controladorResumen != null) {
            controladorResumen.mostrarSoloCotizaciones();
        }
    }//GEN-LAST:event_CotizacionesActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        if (controladorResumen != null) {
            controladorResumen.mostrarSoloVentasDirectas();
        }
    }//GEN-LAST:event_jButton5ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cotizaciones;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable11;
    // End of variables declaration//GEN-END:variables
}
