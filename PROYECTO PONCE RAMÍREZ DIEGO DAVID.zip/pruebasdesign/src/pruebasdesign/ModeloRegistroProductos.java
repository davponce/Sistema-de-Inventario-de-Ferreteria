package pruebasdesign;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author diego
 */
public class ModeloRegistroProductos {
    frmProductosInternal frmInternalProductos;
    Pila pila;
    Producto producto;

    public ModeloRegistroProductos(frmProductosInternal frmInternalProductos, Pila pila, Producto producto) {
        this.frmInternalProductos = frmInternalProductos;
        this.pila = pila;
        this.producto = producto;
    }
    
    public void agregarProducto(String idProducto, String codigo, String descripcion, int categoria, int subcategoria, int stockActual, double precioCompra){
        Producto producto = new Producto();
        producto.setIdProducto(idProducto);
        producto.setCodigo(codigo);
        producto.setDescripcion(descripcion);
        producto.setCategoria(categoria);
        producto.setSubcategoria(subcategoria);
        producto.setStockActual(stockActual);
        producto.setPrecioCompra(precioCompra);
        
        pila.push(producto);
    }
    
    public Producto buscar(String idBuscar) {
    if(pila == null || pila.estaVacia()) {
        return null;
    }
 
    Nodo aux = pila.getPila();
    while(aux != null) {
        Producto productoActual = (Producto) aux.getValor();
        if(productoActual.getIdProducto().equals(idBuscar)) {
            return productoActual;
        }
        aux = aux.getSiguiente();
    }
    return null;
}
    
    
public Producto eliminar(String idBuscar){
    if(pila == null || pila.estaVacia()) {
        return null;
    }
 
    Nodo aux = pila.getPila();
    while(aux != null) {
        Producto productoActual = (Producto) aux.getValor();
        if(productoActual.getIdProducto().equals(idBuscar)) {
            pila.eliminar(idBuscar);
            return productoActual;
        }
        aux = aux.getSiguiente();
    }
    return null;
}

public List<Producto> stock() {
    List<Producto> productosBajoStock = new ArrayList<>();
    
    if(pila == null || pila.estaVacia()) {
        return productosBajoStock;
    }
    
    Nodo aux = pila.getPila();
    while(aux != null) {
        Producto productoActual = (Producto) aux.getValor();
        if(productoActual.getStockActual() <= 10) {
            productosBajoStock.add(productoActual);
        }
        aux = aux.getSiguiente();
    }
    
    return productosBajoStock;
}
    
public Pila obtenerPilaProductos() {
    return this.pila; 
}

}
