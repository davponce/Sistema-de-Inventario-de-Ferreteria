package pruebasdesign;

/**
 *
 * @author Lenovo
 */
public class Producto {
    private String idProducto;
    private String codigo;
    private String descripcion;
    private int categoria;
    private int subcategoria;
    private int stockActual;
    private double precioCompra;
    
    public Producto() {
        super(); 
    }

    public Producto(String idProducto, String codigo, String descripcion, int categoria, int subcategoria, int stockActual, double precioCompra) {
        this.idProducto = idProducto;
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.subcategoria = subcategoria;
        this.stockActual = stockActual;
        this.precioCompra = precioCompra;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public int getSubcategoria() {
        return subcategoria;
    }

    public void setSubcategoria(int subcategoria) {
        this.subcategoria = subcategoria;
    }

    public int getStockActual() {
        return stockActual;
    }

    public void setStockActual(int stockActual) {
        this.stockActual = stockActual;
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(double precioCompra) {
        this.precioCompra = precioCompra;
    }

    @Override
    public String toString() {
        return descripcion + " - $" + precioCompra + " (Stock: " + stockActual + ")";
    }
    
    // Método para reducir stock
    public boolean reducirStock(int cantidad) {
        if (cantidad <= stockActual) {
            stockActual -= cantidad;
            return true;
        }
        return false;
    }
}