//Axel Xaviani Ibarra Villanueva
package pruebasdesign;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author Axel Ibarra
 */

public class imagenFondo extends JPanel{
            private Image imagen; 
            private ImageIcon imagenIcono; 
            public imagenFondo (String ruta){
                imagenIcono = new ImageIcon (ruta); 
            }
            
    public void paint(Graphics g){
        //se establece la imagen a colocar de fondo
        imagen = imagenIcono.getImage(); 
        //obtiene el tamaño de ventana para dibujar la imagen 
        g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        //coloca la transparencia de ventana
        setOpaque(false);
        //redibuja la ventana
        super.paint(g);
    }
}//class

