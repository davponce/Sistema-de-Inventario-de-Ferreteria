package pruebasdesign;

/**
 *
 * @author diego
 */
public class GestorDatos {
    private static GestorDatos instancia;
    private Cola colaClientes;
    private Pila pilaProductos;
    private Pila pilaVentas;
    private Pila pilaCotizaciones;
    
    private GestorDatos() {
        this.colaClientes = new Cola();
        this.pilaProductos = new Pila();
        this.pilaVentas = new Pila();
        this.pilaCotizaciones = new Pila(); // Inicializar aquí también
    }
    
    public static GestorDatos obtenerInstancia() {
        if (instancia == null) {
            instancia = new GestorDatos();
        }
        return instancia;
    }
    
    public Cola getColaClientes() {
        return colaClientes;
    }
    
    public Pila getPilaProductos() {
        return pilaProductos;
    }
    
    public Pila getPilaVentas() {
        return pilaVentas;
    }
    
    // AGREGAR ESTOS MÉTODOS PARA COTIZACIONES:
    public Pila getPilaCotizaciones() {
        return pilaCotizaciones;
    }
    
    public void setPilaCotizaciones(Pila pilaCotizaciones) {
        this.pilaCotizaciones = pilaCotizaciones;
    }
    
    public void resetearDatos() {
        this.colaClientes = new Cola();
        this.pilaProductos = new Pila();
        this.pilaVentas = new Pila();
        this.pilaCotizaciones = new Pila(); // Resetear también
    }
}