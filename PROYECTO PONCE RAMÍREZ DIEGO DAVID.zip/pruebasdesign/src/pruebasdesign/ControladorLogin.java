package pruebasdesign;

import javax.swing.JOptionPane;

/**
 *
 * @author diego
 */
public class ControladorLogin {
    private FrmLogin login;
    private FrmPrincipal principal;
    private ModeloLogin modelo;

    public ControladorLogin(FrmLogin login, FrmPrincipal principal, ModeloLogin modelo) {
        this.login = login;
        this.principal = principal;
        this.modelo = modelo;
    }
    
  public void ingresar(){
    String usuario = login.getUsuario();
    String contrasena = login.getContrasena();
    
    if(usuario.trim().isEmpty() || contrasena.trim().isEmpty()) {
        mostrarError("Por favor ingrese usuario y contraseña");
        return;
    }
    
    boolean resultado = modelo.validarSesion(usuario, contrasena);
    if(resultado) {
        principal.setVisible(true);
        login.setVisible(false);
    } else {
        mostrarError("Usuario o contraseña incorrectos");
    }
}
    
    public void salir(){
        login.dispose();
    }
   
    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
