 package pruebasdesign;
/**
 *
 * @author diego
 */
public class Nodo {
    private Object valor;
    private Nodo siguiente;
    
    public Nodo(Object v){
        this.valor = v;
        this.siguiente = null;
    }

    public Object getValor() {
        return valor;
    }

    public void setValor(Object valor) {
        this.valor = valor;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
}
