package pruebasdesign;
/**
 *
 * @author diego
 */
public class ModeloRegistroClientes {
    frmClientesInternal frmInternalClientes;
    Cola cola;
    Cliente cliente;

    public ModeloRegistroClientes(frmClientesInternal frmInternalClientes, Cliente cliente, Cola cola) {
        this.frmInternalClientes = frmInternalClientes;
        this.cliente = cliente;
        this.cola = cola;
    }
    
    public void agregarCliente(String id, String tipo, String rfc, String direccion, int credito, String nombre, int genero, boolean activo, String telefono, String edad){
       Cliente cliente = new Cliente();
       cliente.setNombre(nombre);
       cliente.setGenero(genero);
       cliente.setActivo(activo);
       cliente.setNumTelefonico(telefono);
       cliente.setEdad(edad);
       cliente.setIdCliente(id);
       cliente.setTipoCliente(tipo);
       cliente.setRfc(rfc);
       cliente.setDireccion(direccion);
       cliente.setDiasCredito(credito);
       
       cola.encolar(cliente);
    }
    
public Cliente buscar(String idBuscar) {
    if(cola == null || cola.estaVacia()) {
        return null;
    }
 
    Nodo aux = cola.getFrente();
    while(aux != null) {
        Cliente clienteActual = (Cliente) aux.getValor();
        if(clienteActual.getIdCliente().equals(idBuscar)) {
            return clienteActual;
        }
        aux = aux.getSiguiente();
    }
    return null;
}

public Cola obtenerColaClientes() {
    return this.cola; 
}

public Cliente eliminar(String idBuscar){
    if(cola == null || cola.estaVacia()) {
        return null;
    }
 
    Nodo aux = cola.getFrente();
    while(aux != null) {
        Cliente clienteActual = (Cliente) aux.getValor();
        if(clienteActual.getIdCliente().equals(idBuscar)) {
            cola.desencolar();
        }
        aux = aux.getSiguiente();
    }
    return null;
}

// En la clase ModeloRegistroClientes
public void modificarCliente(String id, String tipo, String rfc, String direccion, 
                            int credito, String nombre, int genero, boolean activo, 
                            String telefono, String edad) {   
    Cliente cliente = buscar(id);
    if (cliente != null) {
        cliente.setTipoCliente(tipo);
        cliente.setRfc(rfc);
        cliente.setDireccion(direccion);
        cliente.setDiasCredito(credito);
        cliente.setNombre(nombre);
        cliente.setGenero(genero);
        cliente.setActivo(activo);
        cliente.setNumTelefonico(telefono);
        cliente.setEdad(edad);
    }
}
    
}
