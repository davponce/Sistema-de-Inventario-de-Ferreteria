package pruebasdesign;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author diego
 */
public class ControladorRegistroProductos {
    frmProductosInternal frmProductos;
    ModeloRegistroProductos registroProductos;
    Pila pilaProductos;

    public ControladorRegistroProductos(frmProductosInternal frmProductos, ModeloRegistroProductos registroProductos) {
        this.frmProductos = frmProductos;
        this.registroProductos = registroProductos;
    }
    
        public void agregar(){
        String id = frmProductos.getId();
        String codigo = frmProductos.getCodigo();
        String descripcion = frmProductos.getDescripcion();
        String stock = frmProductos.getStock();
        String precio = frmProductos.getPrecio();
        int categoria = frmProductos.getCategoria();
        int subcategoria = frmProductos.getSubcategoria();
       
        if(id.isEmpty() || codigo.isEmpty() || descripcion.isEmpty() || stock.isEmpty() || 
           precio.isEmpty()){
            mostrarError("Faltan campos por llenar");
            return;
        } 
        
        try {
            double precioCosto = Double.parseDouble(precio);
            int stockN = Integer.parseInt(stock);
            
            registroProductos.agregarProducto(id, codigo, descripcion, categoria, subcategoria, stockN, precioCosto);
            
            JOptionPane.showMessageDialog(null, "Producto agregado exitosamente", 
                                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (NumberFormatException e) {
            mostrarError("Error en campos numéricos: precio y stock deben ser números válidos");
        }
    }
        
    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    public void limpiar(){
        frmProductos.limpiarCampos();
    }
    
    public void limpiar2(){
        frmProductos.limpiarCampos2();
    }
     
     public void limpiarTabla(){
         frmProductos.limpiarTabla();
     }
     
     public void buscar(){
    String id = frmProductos.buscar();
    
    if(id.isEmpty()){
        mostrarError("Ingrese un ID para buscar");
        return;
    }
    
    Producto productoEncontrado = registroProductos.buscar(id);
    
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID", "Descripción", "Categoría", "Subcategoría", "Stock inicial", "Precio"}, 0
    );
    
    if(productoEncontrado != null){
        modelo.addRow(new Object[]{
            productoEncontrado.getIdProducto(),
            productoEncontrado.getDescripcion(),
            productoEncontrado.getCategoria() ,
            productoEncontrado.getSubcategoria(),
            productoEncontrado.getStockActual(),
            productoEncontrado.getPrecioCompra()
        });
        
        JOptionPane.showMessageDialog(null, "Producto encontrado", 
                                    "Búsqueda exitosa", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(null, "Producto con ID " + id + " no encontrado", 
                                    "Búsqueda", JOptionPane.WARNING_MESSAGE);
    }
    
    frmProductos.jTable1.setModel(modelo);
}
     
     public void buscarModificar(){
        String id = frmProductos.getId2();

        if(id.isEmpty()){
            mostrarError("Ingrese un ID para buscar");
            return;
        }
        
         Producto productoEncontrado = registroProductos.buscar(id);
         if(productoEncontrado != null){
             frmProductos.jtfId2.setText(productoEncontrado.getIdProducto());
             frmProductos.jtaDescripcion2.setText(productoEncontrado.getDescripcion());
             frmProductos.jcbCategoria2.setSelectedIndex(productoEncontrado.getCategoria());
             frmProductos.jlsSub2.setSelectedIndex(productoEncontrado.getSubcategoria());
             frmProductos.jtfStock2.setText(String.valueOf(productoEncontrado.getStockActual()));
             frmProductos.jtfPrecio2.setText(String.valueOf(productoEncontrado.getPrecioCompra()));
             frmProductos.jtfCodigo2.setText(productoEncontrado.getCodigo());
         }
       
     }
     
     public void modificar(){
        String id = frmProductos.getId2();
        String codigo = frmProductos.getCodigo2();
        String descripcion = frmProductos.getDescripcion2();
        String stock = frmProductos.getStock2();
        String precio = frmProductos.getPrecio2();
        int categoria = frmProductos.getCategoria2();
        int subcategoria = frmProductos.getSubcategoria2();
       
        if(id.isEmpty() || codigo.isEmpty() || descripcion.isEmpty() || stock.isEmpty() || 
           precio.isEmpty()){
            mostrarError("Faltan campos por llenar");
            return;
        } 
        
        try {
            double precioCosto = Double.parseDouble(precio);
            int stockN = Integer.parseInt(stock);
            
            registroProductos.agregarProducto(id, codigo, descripcion, categoria, subcategoria, stockN, precioCosto);
            
            JOptionPane.showMessageDialog(null, "Producto modificado exitosamente", 
                                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (NumberFormatException e) {
            mostrarError("Error en campos numéricos: precio y stock deben ser números válidos");
        }
     }
    
     public void eliminar(){
    String id = frmProductos.buscar();
    
    if(id.isEmpty()){
        mostrarError("Ingrese un ID para eliminar");
        return;
    }
    
    Producto productoEncontrado = registroProductos.eliminar(id);
    
    JOptionPane.showMessageDialog(null, "Producto eliminado", 
                                    "Búsqueda exitosa", JOptionPane.INFORMATION_MESSAGE);
    
    frmProductos.limpiarTabla();
    
    }
     
    public void stock() {
    List<Producto> productosBajoStock = registroProductos.stock(); 
    if (productosBajoStock == null || productosBajoStock.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No hay productos con stock bajo (menos de 10 unidades).");
        return;
    }
    
    StringBuilder mensaje = new StringBuilder();
    mensaje.append("Productos con stock bajo (menos de 10 unidades):\n\n");
    
    for (Producto producto : productosBajoStock) {
        mensaje.append("ID: ").append(producto.getIdProducto())
               .append(" - Nombre: ").append(producto.getDescripcion())
               .append(" - Stock: ").append(producto.getStockActual())
               .append("\n");
    }
    
    JOptionPane.showMessageDialog(null, mensaje.toString(), "Stock Bajo", JOptionPane.INFORMATION_MESSAGE);
}
     
    public void mostrar(){
    // Crear el modelo de la tabla
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID", "Descripción", "Categoría", "Subcategoría", "Stock inicial", "Precio"}, 0
    );
    
    frmProductos.jTable1.setModel(modelo);
    
    Pila pilaProductos = registroProductos.obtenerPilaProductos();

    if(pilaProductos != null && !pilaProductos.estaVacia()) {
        Nodo aux = pilaProductos.getPila();
        
        while (aux != null) {
            Producto l = (Producto) aux.getValor();
            modelo.addRow(new Object[]{
               l.getIdProducto(),
               l.getDescripcion(),
               l.getCategoria() ,
               l.getSubcategoria(),
               l.getStockActual(),
               l.getPrecioCompra()
            });
            
            aux = aux.getSiguiente();
        }
    }
}
}
