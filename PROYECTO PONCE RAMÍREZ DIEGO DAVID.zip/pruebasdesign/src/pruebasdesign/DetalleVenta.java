package pruebasdesign;

/**
 *
 * @author Lenovo
 */
public class DetalleVenta {
    private int idDetalle;
    private int cantidad;
    private double precioUnitario;
    private double descuento;
    private double subtotalLinea;
}
