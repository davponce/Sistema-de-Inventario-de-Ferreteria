package pruebasdesign;

import java.time.LocalDateTime;

/**
 *
 * @author diego
 */
public class ModeloRegistroVentas {
    frmVentasInternal frmInternalVentas;
    Pila pila;
    Venta venta;

    public ModeloRegistroVentas(frmVentasInternal frmInternalVentas, Pila pila, Venta venta) {
        this.frmInternalVentas = frmInternalVentas;
        this.pila = pila;
        this.venta = venta;
    }
    
    public void agregarVenta(LocalDateTime fecha, String id, int tipoVenta, int cantidad, 
                        Cliente cliente, Producto producto, double descuento, 
                        double subtotal, double total, boolean pagoCompleto){
    
    if(producto != null && producto.getStockActual() < cantidad) {
        throw new IllegalArgumentException("Stock insuficiente. Stock actual: " + 
                                          producto.getStockActual() + 
                                          ", Cantidad solicitada: " + cantidad);
    }
    
    if(producto != null) {
        boolean stockReducido = producto.reducirStock(cantidad);
        if(!stockReducido) {
            throw new IllegalArgumentException("No se pudo reducir el stock del producto");
        }
    }
    
    Venta venta = new Venta();
    venta.setFecha(fecha);
    venta.setId(id);
    venta.setTipoVenta(tipoVenta);
    venta.setCantidad(cantidad);
    venta.setClientes(cliente);
    venta.setProducto(producto);
    venta.setDescuento(descuento);
    venta.setSubtotal(subtotal);
    venta.setTotal(total);
    venta.setPagoCompleto(pagoCompleto);
    
    pila.push(venta);
}
     
    public Venta buscar(String idBuscar) {
    if(pila == null || pila.estaVacia()) {
        return null;
    }
 
    Nodo aux = pila.getPila();
    while(aux != null) {
        Venta ventaActual = (Venta) aux.getValor();
        if(ventaActual.getId().equals(idBuscar)) {
            return ventaActual;
        }
        aux = aux.getSiguiente();
    }
    return null;
}
    
    public Venta eliminar(String idBuscar){
    if(pila == null || pila.estaVacia()) {
        return null;
    }
 
    Nodo aux = pila.getPila();
    while(aux != null) {
        Venta ventaActual = (Venta) aux.getValor();
        if(ventaActual.getId().equals(idBuscar)) {
            // Devolver el stock al producto antes de eliminar la venta
            Producto producto = ventaActual.getProducto();
            if(producto != null) {
                int cantidadVenta = ventaActual.getCantidad();
                producto.setStockActual(producto.getStockActual() + cantidadVenta);
            }
            
            pila.eliminar(idBuscar);
            return ventaActual;
        }
        aux = aux.getSiguiente();
    }
    return null;
}
    
    public Pila obtenerPilaVentas() {
    return this.pila; 
}
    
    public boolean modificarVenta(String idBuscar, LocalDateTime fecha, String nuevoId, 
                           int tipoVenta, int cantidad, Cliente cliente, 
                           Producto producto, double descuento, double subtotal, 
                           double total, boolean pagoCompleto) {
    if(pila == null || pila.estaVacia()) {
        return false;
    }
 
    Nodo aux = pila.getPila();
    while(aux != null) {
        Venta ventaActual = (Venta) aux.getValor();
        if(ventaActual.getId().equals(idBuscar)) {
            // Obtener el producto y cantidad original
            Producto productoOriginal = ventaActual.getProducto();
            int cantidadOriginal = ventaActual.getCantidad();
            
            // Si cambia el producto o la cantidad, ajustar stocks
            if(productoOriginal != null && producto != null) {
                // Si es el mismo producto pero diferente cantidad
                if(productoOriginal.getIdProducto().equals(producto.getIdProducto())) {
                    int diferencia = cantidad - cantidadOriginal;
                    
                    if(diferencia > 0) {
                        // Se necesita más producto
                        if(producto.getStockActual() < diferencia) {
                            throw new IllegalArgumentException(
                                "Stock insuficiente para la modificación.\n" +
                                "Stock disponible: " + producto.getStockActual() + 
                                "\nCantidad adicional requerida: " + diferencia);
                        }
                        producto.reducirStock(diferencia);
                    } else if(diferencia < 0) {
                        // Se devuelve producto al stock
                        producto.setStockActual(producto.getStockActual() + Math.abs(diferencia));
                    }
                } else {
                    // Son productos diferentes
                    // Devolver stock al producto original
                    productoOriginal.setStockActual(
                        productoOriginal.getStockActual() + cantidadOriginal);
                    
                    // Reducir stock del nuevo producto
                    if(producto.getStockActual() < cantidad) {
                        // Revertir el cambio en el producto original
                        productoOriginal.reducirStock(cantidadOriginal);
                        throw new IllegalArgumentException(
                            "Stock insuficiente del nuevo producto.\n" +
                            "Stock disponible: " + producto.getStockActual());
                    }
                    producto.reducirStock(cantidad);
                }
            }
            
            // Actualizar la venta
            ventaActual.setFecha(fecha);
            ventaActual.setId(nuevoId);
            ventaActual.setTipoVenta(tipoVenta);
            ventaActual.setCantidad(cantidad);
            ventaActual.setClientes(cliente);
            ventaActual.setProducto(producto);
            ventaActual.setDescuento(descuento);
            ventaActual.setSubtotal(subtotal);
            ventaActual.setTotal(total);
            ventaActual.setPagoCompleto(pagoCompleto);
            return true;
        }
        aux = aux.getSiguiente();
    }
    return false;
}
    
    

}
