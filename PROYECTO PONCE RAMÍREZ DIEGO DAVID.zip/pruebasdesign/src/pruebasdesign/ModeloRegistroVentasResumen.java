package pruebasdesign;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author diego
 */
public class ModeloRegistroVentasResumen {
    private frmResumenInternal vista;
    private Pila pilaVentas;
    private Venta venta;

    public ModeloRegistroVentasResumen(frmResumenInternal vista, Pila pilaVentas, Venta venta) {
        this.vista = vista;
        this.pilaVentas = pilaVentas;
        this.venta = venta;
        System.out.println("Modelo de Resumen de Ventas inicializado");
    }
    
    // Método para mostrar todas las ventas en la tabla con diferenciación
    public void mostrarVentasEnTabla() {
        try {
            System.out.println("Mostrando " + pilaVentas.tamaño() + " ventas en la tabla...");
            
            // Agregamos una columna para "Origen"
            DefaultTableModel modelo = new DefaultTableModel(
                new Object[]{"ID", "Origen", "Fecha", "Tipo Venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado Pago"}, 0
            ) {
                @Override
                public Class<?> getColumnClass(int columnIndex) {
                    return String.class;
                }
                
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Todas las celdas son de solo lectura
                }
            };
            
            if (pilaVentas.estaVacia()) {
                vista.jTable11.setModel(modelo);
                return;
            }
            
            Nodo aux = pilaVentas.getPila();
            int contador = 0;
            int ventasDeCotizacion = 0;
            int ventasDirectas = 0;
            
            while (aux != null) {
                Venta v = (Venta) aux.getValor();
                if (v != null) {
                    contador++;
                    
                    // Determinar el origen de la venta
                    String origen = determinarOrigenVenta(v.getId());
                    if (origen.equals("Cotización")) {
                        ventasDeCotizacion++;
                    } else {
                        ventasDirectas++;
                    }
                    
                    String tipoVenta = v.getTipoVenta() == 1 ? "Contado" : "Crédito";
                    String estadoPago = v.isPagoCompleto() ? "Completo" : "Pendiente";
                    String nombreCliente = (v.getClientes() != null) ? v.getClientes().getNombre() : "N/A";
                    String descripcionProducto = (v.getProducto() != null) ? v.getProducto().getDescripcion() : "N/A";
                    String fechaStr = (v.getFecha() != null) ? v.getFecha().toString() : "N/A";
                    
                    modelo.addRow(new Object[]{
                        v.getId(),
                        origen,
                        fechaStr,
                        tipoVenta,
                        v.getCantidad(),
                        nombreCliente,
                        descripcionProducto,
                        String.format("%.0f%%", v.getDescuento() * 100),
                        String.format("$%.2f", v.getSubtotal()),
                        String.format("$%.2f", v.getTotal()),
                        estadoPago
                    });
                    
                    System.out.println("Venta " + contador + ": " + v.getId() + 
                                     " - Origen: " + origen + 
                                     " - Cliente: " + nombreCliente + 
                                     " - Total: $" + v.getTotal());
                }
                aux = aux.getSiguiente();
            }
            
            vista.jTable11.setModel(modelo);
            
            // Mostrar estadísticas de origen
            System.out.println("=== ESTADÍSTICAS POR ORIGEN ===");
            System.out.println("Ventas de Cotización: " + ventasDeCotizacion);
            System.out.println("Ventas Directas: " + ventasDirectas);
            System.out.println("Total de ventas: " + contador);
            System.out.println("===============================");
            
        } catch (Exception e) {
            System.err.println("Error en mostrarVentasEnTabla: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
    
    // Método para determinar el origen de una venta
    private String determinarOrigenVenta(String idVenta) {
        if (idVenta == null || idVenta.isEmpty()) {
            return "Desconocido";
        }
        
        // Si el ID empieza con "VEN-", proviene de una cotización
        if (idVenta.startsWith("VEN-")) {
            return "Cotización";
        } 
        // Si el ID empieza con "VT-", es una venta directa (puedes ajustar este patrón)
        else if (idVenta.startsWith("VT-")) {
            return "Venta Directa";
        }
        // Para otros patrones de ID
        else {
            return "Venta Directa";
        }
    }
    
    // Método para filtrar ventas por origen
    public void filtrarVentasPorOrigen(String origen) {
        try {
            DefaultTableModel modelo = new DefaultTableModel(
                new Object[]{"ID", "Origen", "Fecha", "Tipo Venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado Pago"}, 0
            );
            
            if (pilaVentas.estaVacia()) {
                vista.jTable11.setModel(modelo);
                vista.mostrarMensaje("No hay ventas registradas", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            Nodo aux = pilaVentas.getPila();
            int contador = 0;
            
            while (aux != null) {
                Venta v = (Venta) aux.getValor();
                if (v != null) {
                    String origenVenta = determinarOrigenVenta(v.getId());
                    
                    if (origenVenta.equals(origen)) {
                        contador++;
                        
                        String tipoVenta = v.getTipoVenta() == 1 ? "Contado" : "Crédito";
                        String estadoPago = v.isPagoCompleto() ? "Completo" : "Pendiente";
                        String nombreCliente = (v.getClientes() != null) ? v.getClientes().getNombre() : "N/A";
                        String descripcionProducto = (v.getProducto() != null) ? v.getProducto().getDescripcion() : "N/A";
                        String fechaStr = (v.getFecha() != null) ? v.getFecha().toString() : "N/A";
                        
                        modelo.addRow(new Object[]{
                            v.getId(),
                            origenVenta,
                            fechaStr,
                            tipoVenta,
                            v.getCantidad(),
                            nombreCliente,
                            descripcionProducto,
                            String.format("%.0f%%", v.getDescuento() * 100),
                            String.format("$%.2f", v.getSubtotal()),
                            String.format("$%.2f", v.getTotal()),
                            estadoPago
                        });
                    }
                }
                aux = aux.getSiguiente();
            }
            
            vista.jTable11.setModel(modelo);
            
            if (contador > 0) {
                vista.mostrarMensaje("Se encontraron " + contador + " ventas de origen: " + origen, 
                                   "Filtro aplicado", JOptionPane.INFORMATION_MESSAGE);
            } else {
                vista.mostrarMensaje("No se encontraron ventas de origen: " + origen, 
                                   "Filtro", JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception e) {
            System.err.println("Error en filtrarVentasPorOrigen: " + e.getMessage());
            e.printStackTrace();
            vista.mostrarMensaje("Error al aplicar filtro: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para filtrar ventas por tipo (0=Crédito, 1=Contado)
    public void filtrarVentasPorTipo(int tipo) {
        try {
            DefaultTableModel modelo = new DefaultTableModel(
                new Object[]{"ID", "Origen", "Fecha", "Tipo Venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado Pago"}, 0
            );
            
            String tipoBuscado = (tipo == 1) ? "Contado" : "Crédito";
            
            if (pilaVentas.estaVacia()) {
                vista.jTable11.setModel(modelo);
                vista.mostrarMensaje("No hay ventas registradas", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            Nodo aux = pilaVentas.getPila();
            int contador = 0;
            
            while (aux != null) {
                Venta v = (Venta) aux.getValor();
                if (v != null) {
                    String tipoVenta = v.getTipoVenta() == 1 ? "Contado" : "Crédito";
                    
                    if (tipoVenta.equals(tipoBuscado)) {
                        contador++;
                        
                        String origenVenta = determinarOrigenVenta(v.getId());
                        String estadoPago = v.isPagoCompleto() ? "Completo" : "Pendiente";
                        String nombreCliente = (v.getClientes() != null) ? v.getClientes().getNombre() : "N/A";
                        String descripcionProducto = (v.getProducto() != null) ? v.getProducto().getDescripcion() : "N/A";
                        String fechaStr = (v.getFecha() != null) ? v.getFecha().toString() : "N/A";
                        
                        modelo.addRow(new Object[]{
                            v.getId(),
                            origenVenta,
                            fechaStr,
                            tipoVenta,
                            v.getCantidad(),
                            nombreCliente,
                            descripcionProducto,
                            String.format("%.0f%%", v.getDescuento() * 100),
                            String.format("$%.2f", v.getSubtotal()),
                            String.format("$%.2f", v.getTotal()),
                            estadoPago
                        });
                    }
                }
                aux = aux.getSiguiente();
            }
            
            vista.jTable11.setModel(modelo);
            
            if (contador > 0) {
                vista.mostrarMensaje("Se encontraron " + contador + " ventas de tipo " + tipoBuscado, 
                                   "Filtro aplicado", JOptionPane.INFORMATION_MESSAGE);
            } else {
                vista.mostrarMensaje("No se encontraron ventas de tipo " + tipoBuscado, 
                                   "Filtro", JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception e) {
            System.err.println("Error en filtrarVentasPorTipo: " + e.getMessage());
            e.printStackTrace();
            vista.mostrarMensaje("Error al aplicar filtro: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para obtener la pila de ventas
    public Pila obtenerPilaVentas() {
        return this.pilaVentas;
    }
    
    // Método para buscar una venta por ID
    public Venta buscarVenta(String id) {
        if (pilaVentas == null || pilaVentas.estaVacia()) {
            return null;
        }
        
        Nodo aux = pilaVentas.getPila();
        while (aux != null) {
            Venta ventaActual = (Venta) aux.getValor();
            if (ventaActual != null && ventaActual.getId().equals(id)) {
                return ventaActual;
            }
            aux = aux.getSiguiente();
        }
        return null;
    }
    
    // Método para obtener estadísticas por origen
    public void mostrarEstadisticasPorOrigen() {
        if (pilaVentas == null || pilaVentas.estaVacia()) {
            System.out.println("No hay ventas para mostrar estadísticas");
            return;
        }
        
        int ventasCotizacion = 0;
        int ventasDirectas = 0;
        double totalCotizacion = 0.0;
        double totalDirectas = 0.0;
        
        Nodo aux = pilaVentas.getPila();
        while (aux != null) {
            Venta v = (Venta) aux.getValor();
            if (v != null) {
                String origen = determinarOrigenVenta(v.getId());
                if (origen.equals("Cotización")) {
                    ventasCotizacion++;
                    totalCotizacion += v.getTotal();
                } else {
                    ventasDirectas++;
                    totalDirectas += v.getTotal();
                }
            }
            aux = aux.getSiguiente();
        }
        
        System.out.println("=== ESTADÍSTICAS DETALLADAS POR ORIGEN ===");
        System.out.println("VENTAS DE COTIZACIÓN:");
        System.out.println("  Cantidad: " + ventasCotizacion);
        System.out.println("  Total: $" + String.format("%.2f", totalCotizacion));
        System.out.println("  Promedio: $" + String.format("%.2f", ventasCotizacion > 0 ? totalCotizacion / ventasCotizacion : 0));
        System.out.println("VENTAS DIRECTAS:");
        System.out.println("  Cantidad: " + ventasDirectas);
        System.out.println("  Total: $" + String.format("%.2f", totalDirectas));
        System.out.println("  Promedio: $" + String.format("%.2f", ventasDirectas > 0 ? totalDirectas / ventasDirectas : 0));
        System.out.println("TOTAL GENERAL:");
        System.out.println("  Ventas totales: " + (ventasCotizacion + ventasDirectas));
        System.out.println("  Monto total: $" + String.format("%.2f", totalCotizacion + totalDirectas));
        System.out.println("==========================================");
    }
}