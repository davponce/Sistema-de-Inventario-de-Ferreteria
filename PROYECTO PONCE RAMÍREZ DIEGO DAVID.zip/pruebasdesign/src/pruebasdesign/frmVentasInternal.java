package pruebasdesign;
import javax.swing.event.ChangeListener;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DateEditor;
import javax.swing.SpinnerDateModel;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Lenovo
 */
public class frmVentasInternal extends javax.swing.JInternalFrame {
    ControladorRegistroVentas registro;
    /**
     * Creates new form frmVentasInternal
     */
    public JSpinner fechaSpinner;
    Cola colaClientes;
    Pila pilaProductos;
    public frmVentasInternal() {
        initComponents();
        GestorDatos gestor = GestorDatos.obtenerInstancia();
        this.colaClientes = gestor.getColaClientes();
        this.pilaProductos = gestor.getPilaProductos();
        Pila pilaVentas = gestor.getPilaVentas();
        Venta ventas = new Venta();
        ModeloRegistroVentas modelo = new ModeloRegistroVentas(this, pilaVentas, ventas);
        registro = new ControladorRegistroVentas(this, modelo);
        crearSelectorFecha(); 
        
        cargarComboClientes();
        cargarComboProductos();
        java.awt.Point posicionLabel = jLabel7.getLocation();
        java.awt.Dimension tamañoLabel = jLabel7.getSize();
    
    fechaSpinner.setBounds(
        posicionLabel.x,                    
        posicionLabel.y + tamañoLabel.height + 5,  
        150,                                
        25                                 
    );

    jpFecha.add(fechaSpinner);
    
    revalidate();
    repaint();
        actualizarEtiquetasCostos();
        jsbCantidad.setMinimum(1);
        jsbCantidad.setMaximum(30);
        jsbCantidad.setValue(1);
        jlbSubtotal.setText("$0.00");
        jlbIva.setText("$0.00");
        jlbTotal.setText("$0.00");
        jcbProducto.addActionListener(e -> actualizarEtiquetasCostos());
        jcbDescuento.addActionListener(e -> actualizarEtiquetasCostos());
        jsbCantidad.addAdjustmentListener(e -> {
        jlbCantidad.setText("Cantidad: " + jsbCantidad.getValue());
        actualizarEtiquetasCostos();
});
    }
    
    private void cargarComboClientes() {
    jcbClientes.removeAllItems();
    Nodo actual = colaClientes.getCola();
    int contador = 0;
    while (actual != null) {
        Cliente c = (Cliente) actual.getValor();
        jcbClientes.addItem(c);
        contador++;
        actual = actual.getSiguiente();
    }
}

private void cargarComboProductos() {
    jcbProducto.removeAllItems();
    Nodo actual = pilaProductos.getPila();
    int contador = 0;
    while (actual != null) {
        Producto p = (Producto) actual.getValor();
        jcbProducto.addItem(p);
        contador++;
        actual = actual.getSiguiente();
    }
}

public void actualizarComboBoxes() {
        cargarComboClientes();
        cargarComboProductos();
    }
    
    public void crearSelectorFecha() {
        // Crear un SpinnerDateModel con la fecha actual
        SpinnerDateModel model = new SpinnerDateModel();
        fechaSpinner = new JSpinner(model);
        
        // Configurar el formato de fecha
        DateEditor editor = new JSpinner.DateEditor(fechaSpinner, "dd/MM/yyyy");
        fechaSpinner.setEditor(editor);
        
        // Establecer la fecha actual por defecto
        fechaSpinner.setValue(new Date());
        
        // Configurar tamaño si es necesario
        fechaSpinner.setPreferredSize(new java.awt.Dimension(150, 25));
    }
    
    // Método para obtener la fecha seleccionada como LocalDateTime
    public LocalDateTime getFechaSeleccionada() {
        Date fechaDate = (Date) fechaSpinner.getValue();
        return LocalDateTime.ofInstant(fechaDate.toInstant(), ZoneId.systemDefault());
    }
    
    // Método para establecer una fecha
    public void setFecha(LocalDateTime fecha) {
        Date date = Date.from(fecha.atZone(ZoneId.systemDefault()).toInstant());
        fechaSpinner.setValue(date);
    }
    
    public String getId(){
        String id = jtfIdVenta.getText().trim();
        return id;
    }
    
    public int getTipoVenta(){
        int tipoVenta = jcbVenta.getSelectedIndex();
        return tipoVenta;
    }
    
   public Cliente getCliente(){
    return (Cliente) jcbClientes.getSelectedItem();
}
    
   public Producto getProducto(){
    return (Producto) jcbProducto.getSelectedItem();
}
    
    public double getDescuento(){
        double descuento = jcbDescuento.getSelectedIndex();
        return descuento;
    }
    
    public boolean getPago(){
        return jcbPago.isSelected();
    }
    
    public int getCantidad() {
        return jsbCantidad.getValue();
    }
    
    public double getSubtotal(){
    String subtotal = jlbSubtotal.getText().trim();
    subtotal = subtotal.replace("$", "");
    return Double.parseDouble(subtotal);
}
    
   public double getTotal() {
    String total = jlbTotal.getText().trim();
    total = total.replace("$", "");
    return Double.parseDouble(total);
}
   
   public String buscar(){
       return jtfBusqueda.getText().trim();
   }
    
     private double obtenerCostoBaseActual() {
    if (jcbProducto.getSelectedItem() != null) {
        Producto productoSeleccionado = (Producto) jcbProducto.getSelectedItem();
        return productoSeleccionado.getPrecioCompra();
    }
    return 0.0;
}
     
     private void actualizarEtiquetasCostos() {
    if(jcbProducto.getSelectedItem() != null) {
        Producto productoSeleccionado = (Producto) jcbProducto.getSelectedItem();
        double precioUnitario = productoSeleccionado.getPrecioCompra();
        int cantidad = jsbCantidad.getValue();
        
        double porcentajeDescuento = 0.0;
        switch(jcbDescuento.getSelectedIndex()) {
            case 0: porcentajeDescuento = 0.00; break;  
            case 1: porcentajeDescuento = 0.05; break;  
            case 2: porcentajeDescuento = 0.15; break;  
            case 3: porcentajeDescuento = 0.20; break;  
            case 4: porcentajeDescuento = 0.50; break;  
        }
        
        // Cálculos
        double subtotalSinDescuento = precioUnitario * cantidad;
        double montoDescuento = subtotalSinDescuento * porcentajeDescuento;
        double subtotal = subtotalSinDescuento - montoDescuento;
        double iva = subtotal * 0.16;
        double total = subtotal + iva;
        
        // Actualizar labels
        jlbSubtotal.setText("$" + String.format("%.2f", subtotal));
        jlbIva.setText("$" + String.format("%.2f", iva));
        jlbTotal.setText("$" + String.format("%.2f", total));
    } else {
        jlbSubtotal.setText("$0.00");
        jlbIva.setText("$0.00");
        jlbTotal.setText("$0.00");
    }
}
     public void limpiar(){
         jtfIdVenta.setText("");
         jcbVenta.setSelectedIndex(0);
         jsbCantidad.setValue(1);
         jcbClientes.setSelectedIndex(0);
         jcbProducto.setSelectedIndex(0);
         jcbDescuento.setSelectedIndex(0);
         jcbPago.setSelected(false);
     }
     
      public void limpiarTabla(){
        DefaultTableModel limpio = new DefaultTableModel(
        new Object[]{"ID", "Fecha", "Tipo de Venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado de pago"}, 0 
    );
    
    jTable1.setModel(limpio);
     jtfBusqueda.setText("");
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jtfIdVenta = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jlbTotal = new javax.swing.JLabel();
        jbnRegistrar = new javax.swing.JButton();
        jbnLimpiar = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jcbClientes = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jcbProducto = new javax.swing.JComboBox<>();
        jcbDescuento = new javax.swing.JComboBox<>();
        jcbVenta = new javax.swing.JComboBox<>();
        jlbSubtotal = new javax.swing.JLabel();
        jcbPago = new javax.swing.JCheckBox();
        jsbCantidad = new javax.swing.JScrollBar();
        jpFecha = new javax.swing.JPanel();
        jlbCantidad = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jlbIva = new javax.swing.JLabel();
        jbnBuscarModificar = new javax.swing.JButton();
        jbnModificar = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jbnMostrarTabla = new javax.swing.JButton();
        jbnLimpiarTabla = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jtfBusqueda = new javax.swing.JTextField();
        jbnBuscar = new javax.swing.JButton();
        jbnEliminar = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        jLabel2.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel2.setText("Registrar Nueva Venta");

        jtfIdVenta.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jtfIdVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfIdVentaActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel3.setText("ID Venta");

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel1.setText("Ventas");

        jLabel4.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel4.setText("Fecha ");

        jLabel5.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel5.setText("Tipo de Venta");

        jLabel6.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel6.setText("Subtotal:");

        jLabel7.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel7.setText("Descuento");

        jLabel8.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel8.setText("TOTAL:");

        jlbTotal.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jlbTotal.setText("$0.0");

        jbnRegistrar.setBackground(new java.awt.Color(20, 33, 61));
        jbnRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        jbnRegistrar.setText("Registrar Venta");
        jbnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnRegistrarActionPerformed(evt);
            }
        });

        jbnLimpiar.setBackground(new java.awt.Color(20, 33, 61));
        jbnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        jbnLimpiar.setText("Limpiar");
        jbnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnLimpiarActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel22.setText("Cantidad");

        jLabel14.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel14.setText("Cliente:");

        jcbClientes.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel15.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel15.setText("Producto:");

        jcbProducto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jcbDescuento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0%", "5%", "15%", "20%", "50%" }));
        jcbDescuento.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jcbVenta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Crédito", "Contado" }));
        jcbVenta.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jlbSubtotal.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jlbSubtotal.setText("$0.0");

        jcbPago.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jcbPago.setText("Pago completo");
        jcbPago.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jsbCantidad.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
        jsbCantidad.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jsbCantidad.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                jsbCantidadAdjustmentValueChanged(evt);
            }
        });

        javax.swing.GroupLayout jpFechaLayout = new javax.swing.GroupLayout(jpFecha);
        jpFecha.setLayout(jpFechaLayout);
        jpFechaLayout.setHorizontalGroup(
            jpFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 277, Short.MAX_VALUE)
        );
        jpFechaLayout.setVerticalGroup(
            jpFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        jlbCantidad.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jlbCantidad.setText("Cantidad");

        jLabel9.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel9.setText("Iva:");

        jlbIva.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jlbIva.setText("$0.0");

        jbnBuscarModificar.setBackground(new java.awt.Color(20, 33, 61));
        jbnBuscarModificar.setForeground(new java.awt.Color(255, 255, 255));
        jbnBuscarModificar.setText("Buscar");
        jbnBuscarModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnBuscarModificarActionPerformed(evt);
            }
        });

        jbnModificar.setBackground(new java.awt.Color(20, 33, 61));
        jbnModificar.setForeground(new java.awt.Color(255, 255, 255));
        jbnModificar.setText("Modificar");
        jbnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnModificarActionPerformed(evt);
            }
        });

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/buy.png"))); // NOI18N

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/moneysmall.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jtfIdVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jcbVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jsbCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jlbCantidad)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jbnBuscarModificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jbnRegistrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jbnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jbnLimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap(316, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel14)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel7))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel6)
                                                    .addGap(89, 89, 89))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jlbSubtotal)
                                                    .addGap(112, 112, 112)))
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jlbTotal)
                                                .addComponent(jLabel8)
                                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(18, 18, 18)))
                                    .addComponent(jLabel9)
                                    .addComponent(jlbIva)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jcbClientes, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jcbProducto, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel15))
                                        .addGap(62, 62, 62)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jcbPago)
                                            .addComponent(jcbDescuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addContainerGap(261, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel29)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel29))))
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel7)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtfIdVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jcbDescuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jcbClientes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jcbPago)
                            .addComponent(jLabel15))
                        .addGap(18, 18, 18)
                        .addComponent(jcbProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlbSubtotal)
                            .addComponent(jlbTotal))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jlbIva))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jbnRegistrar)
                            .addComponent(jbnLimpiar)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jpFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jcbVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(jLabel22)
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jsbCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlbCantidad))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbnBuscarModificar)
                    .addComponent(jbnModificar))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Ventas", jPanel1);

        jLabel11.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel11.setText("Resumen de la venta");

        jLabel13.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel13.setText("Inserte el ID de la venta:");

        jbnMostrarTabla.setBackground(new java.awt.Color(20, 33, 61));
        jbnMostrarTabla.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jbnMostrarTabla.setForeground(new java.awt.Color(255, 255, 255));
        jbnMostrarTabla.setText("Mostrar");
        jbnMostrarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnMostrarTablaActionPerformed(evt);
            }
        });

        jbnLimpiarTabla.setBackground(new java.awt.Color(20, 33, 61));
        jbnLimpiarTabla.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jbnLimpiarTabla.setForeground(new java.awt.Color(255, 255, 255));
        jbnLimpiarTabla.setText("Limpiar");
        jbnLimpiarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnLimpiarTablaActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Fecha", "Tipo de Venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado de pago"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        jtfBusqueda.setBackground(new java.awt.Color(229, 229, 229));
        jtfBusqueda.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jtfBusqueda.setForeground(new java.awt.Color(255, 255, 255));
        jtfBusqueda.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jbnBuscar.setBackground(new java.awt.Color(20, 33, 61));
        jbnBuscar.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jbnBuscar.setForeground(new java.awt.Color(255, 255, 255));
        jbnBuscar.setText("Buscar");
        jbnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnBuscarActionPerformed(evt);
            }
        });

        jbnEliminar.setBackground(new java.awt.Color(20, 33, 61));
        jbnEliminar.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jbnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        jbnEliminar.setText("Eliminar");
        jbnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnEliminarActionPerformed(evt);
            }
        });

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ver_grande.png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(182, 182, 182)
                                .addComponent(jLabel11))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jtfBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jbnBuscar)
                                .addGap(18, 18, 18)
                                .addComponent(jbnMostrarTabla)
                                .addGap(18, 18, 18)
                                .addComponent(jbnLimpiarTabla)
                                .addGap(18, 18, 18)
                                .addComponent(jbnEliminar)))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel16)
                        .addGap(0, 324, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel13))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jbnMostrarTabla)
                            .addComponent(jbnLimpiarTabla)
                            .addComponent(jtfBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbnBuscar)
                            .addComponent(jbnEliminar)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel16)))
                .addGap(26, 26, 26)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 46, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Resumen de Venta", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 988, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnEliminarActionPerformed
        registro.eliminar();
    }//GEN-LAST:event_jbnEliminarActionPerformed

    private void jbnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnBuscarActionPerformed
        registro.buscar();
    }//GEN-LAST:event_jbnBuscarActionPerformed

    private void jbnLimpiarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnLimpiarTablaActionPerformed
        registro.limpiarTablas();
    }//GEN-LAST:event_jbnLimpiarTablaActionPerformed

    private void jbnMostrarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnMostrarTablaActionPerformed
        registro.mostrar();
    }//GEN-LAST:event_jbnMostrarTablaActionPerformed

    private void jbnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnModificarActionPerformed
        registro.modificar();
    }//GEN-LAST:event_jbnModificarActionPerformed

    private void jbnBuscarModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnBuscarModificarActionPerformed
        registro.buscarModificar();
    }//GEN-LAST:event_jbnBuscarModificarActionPerformed

    private void jsbCantidadAdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_jsbCantidadAdjustmentValueChanged
        jlbCantidad.setText("Cantidad: " + jsbCantidad.getValue());
        actualizarEtiquetasCostos();
    }//GEN-LAST:event_jsbCantidadAdjustmentValueChanged

    private void jbnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnLimpiarActionPerformed
        registro.limpiar();
    }//GEN-LAST:event_jbnLimpiarActionPerformed

    private void jbnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnRegistrarActionPerformed
        registro.agregarVenta();
    }//GEN-LAST:event_jbnRegistrarActionPerformed

    private void jtfIdVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfIdVentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtfIdVentaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    public javax.swing.JTable jTable1;
    private javax.swing.JButton jbnBuscar;
    private javax.swing.JButton jbnBuscarModificar;
    private javax.swing.JButton jbnEliminar;
    private javax.swing.JButton jbnLimpiar;
    private javax.swing.JButton jbnLimpiarTabla;
    private javax.swing.JButton jbnModificar;
    private javax.swing.JButton jbnMostrarTabla;
    private javax.swing.JButton jbnRegistrar;
    public javax.swing.JComboBox<Cliente> jcbClientes;
    public javax.swing.JComboBox<String> jcbDescuento;
    public javax.swing.JCheckBox jcbPago;
    public javax.swing.JComboBox<Producto> jcbProducto;
    public javax.swing.JComboBox<String> jcbVenta;
    private javax.swing.JLabel jlbCantidad;
    private javax.swing.JLabel jlbIva;
    public javax.swing.JLabel jlbSubtotal;
    public javax.swing.JLabel jlbTotal;
    private javax.swing.JPanel jpFecha;
    public javax.swing.JScrollBar jsbCantidad;
    private javax.swing.JTextField jtfBusqueda;
    public javax.swing.JTextField jtfIdVenta;
    // End of variables declaration//GEN-END:variables
}
