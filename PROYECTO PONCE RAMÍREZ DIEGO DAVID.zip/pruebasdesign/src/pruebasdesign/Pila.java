package pruebasdesign;
/**
 *
 * @author diego
 */
public class Pila {
    private Nodo pila;
    
    public Pila() {
       pila = null; 
    }
    
    // Operación para agregar al inicio de la Pila un nodo (con valor)
    public void push(Object v){
        // Crear el nodo con el valor
        Nodo nuevo = new Nodo(v);
        // Para agregar, primero se valida si hay mas nodos o ninguno
        if(pila == null){
            // Se agregar el primer nodo a la pila
            pila = nuevo;
        } else { // Hay mas nodos y se agrega al final de la pila
            // Genera un apuntador auxiliar para referenciar los demas valores
            Nodo aux = pila;
            // Agregar nuevo nodo al inicio de la pila
            pila = nuevo;
            // Despues del nuevo nodo, se agregan los demas valores
            nuevo.setSiguiente(aux);
        }
    }
    
    // Método para apilar un nodo (corregido)
    public void apilar(Nodo nuevoNodo) {
        if (nuevoNodo == null) {
            throw new IllegalArgumentException("El nodo no puede ser null");
        }
        
        // Validar si hay más nodos o ninguno
        if (pila == null) {
            // Se agrega el primer nodo a la pila
            pila = nuevoNodo;
        } else {
            // Genera un apuntador auxiliar para referenciar los demás valores
            Nodo aux = pila;
            // Agregar nuevo nodo al inicio de la pila
            pila = nuevoNodo;
            // Después del nuevo nodo, se agregan los demás valores
            nuevoNodo.setSiguiente(aux);
        }
        
        System.out.println("Nodo apilado exitosamente");
    }
    
    public String recorrerPila(){
        // Mostrar el contenido de la lista, siempre que no sea vacia
        // Genera un apuntador auxiliar para recorrer la lista
        Nodo aux = pila;
        String valores = "";
        if(pila == null){
            valores = "La pila esta vacia";
        } else {
            valores = "Elementos en la pila \n";
            // Recorrer la pila, mediante el apuntador auxiliar
            while(aux != null){
                valores += aux.getValor().toString() + "\n";
                aux = aux.getSiguiente(); // avanza al siguiente nodo
            }
        }
        return valores;
    }
    
    public String pop(){
        // Eliminar el primer elemento de la pila
        // Genera un apuntador auxiliar para recorrer la Pila
        Nodo aux = pila;
        String valores = "";
        if(pila == null){
            valores = "La pila está vacía";
        } else {
            // Se evalua si existen mas de un elemento en la Pila
            if(aux.getSiguiente() == null){
                // Existe solamente un elemento en la Pila y se elimina
                pila = null;
            } else {
                // Existe mas de un elemento en la Pila y se elimina el primero
                pila = aux.getSiguiente();
            }
            valores = "Primer elemento eliminado";
        }
        return valores;
    }

    public Nodo getPila() {
        return pila;
    }

    public void setPila(Nodo pila) {
        this.pila = pila;
    }
    
    public boolean estaVacia() {
        return pila == null;
    }
    
    public Nodo desapilar() {
        if (pila == null) {
            System.out.println("La pila está vacía");
            return null;
        }
        
        Nodo nodoDesapilado = pila;
        pila = pila.getSiguiente();
        
        if (nodoDesapilado != null) {
            nodoDesapilado.setSiguiente(null);
        }
        
        System.out.println("Nodo desapilado exitosamente");
        return nodoDesapilado;
    }
    
    public Object eliminar(String idBuscar) {
        if (pila == null) {
            return null;
        }

        Nodo actual = pila;
        Nodo anterior = null;

        // Buscar el nodo con el ID
        while (actual != null) {
            Object objetoActual = actual.getValor();
            String idActual = null;
            
            // Determinar el ID según el tipo de objeto
            if (objetoActual instanceof Venta) {
                idActual = ((Venta) objetoActual).getId();
            } else if (objetoActual instanceof Producto) {
                idActual = ((Producto) objetoActual).getIdProducto();
            } else if (objetoActual instanceof Cotizacion) {
                idActual = ((Cotizacion) objetoActual).getId();
            } else {
                // Si no es un tipo reconocido, continuar
                anterior = actual;
                actual = actual.getSiguiente();
                continue;
            }
            
            // Si encontramos el ID
            if (idActual != null && idActual.equals(idBuscar)) {
                Object eliminado = objetoActual;
                
                // Si es el primer nodo (tope)
                if (anterior == null) {
                    pila = actual.getSiguiente();
                } else {
                    // Si es un nodo intermedio
                    anterior.setSiguiente(actual.getSiguiente());
                }
                
                return eliminado;
            }
            
            anterior = actual;
            actual = actual.getSiguiente();
        }
        
        return null; // No se encontró
    }

    // Método para buscar un nodo por ID
    public Nodo buscarPorId(String id) {
        Nodo actual = pila;
        
        while (actual != null) {
            Object objeto = actual.getValor();
            
            if (objeto instanceof Cotizacion) {
                Cotizacion cotizacion = (Cotizacion) objeto;
                if (cotizacion.getId().equals(id)) {
                    return actual;
                }
            } else if (objeto instanceof Producto) {
                Producto producto = (Producto) objeto;
                if (producto.getIdProducto().equals(id)) {
                    return actual;
                }
            } else if (objeto instanceof Venta) {
                Venta venta = (Venta) objeto;
                if (venta.getId().equals(id)) {
                    return actual;
                }
            }
            
            actual = actual.getSiguiente();
        }
        
        return null;
    }
    
    // Método para obtener el tamaño de la pila
    public int tamaño() {
        int contador = 0;
        Nodo actual = pila;
        
        while (actual != null) {
            contador++;
            actual = actual.getSiguiente();
        }
        
        return contador;
    }
    
    // Método para vaciar la pila
    public void vaciar() {
        pila = null;
        System.out.println("Pila vaciada exitosamente");
    }
    
    // Método para mostrar información detallada de la pila
    public void mostrarPilaDetallada() {
        if (pila == null) {
            System.out.println("La pila está vacía");
            return;
        }
        
        System.out.println("=== CONTENIDO DE LA PILA ===");
        Nodo actual = pila;
        int contador = 1;
        
        while (actual != null) {
            Object valor = actual.getValor();
            System.out.println("Nodo " + contador + ": " + valor.getClass().getSimpleName());
            System.out.println("  Valor: " + valor);
            actual = actual.getSiguiente();
            contador++;
        }
        System.out.println("=============================");
    }
}