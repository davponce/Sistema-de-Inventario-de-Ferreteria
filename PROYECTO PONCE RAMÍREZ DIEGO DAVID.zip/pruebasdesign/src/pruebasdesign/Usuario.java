package pruebasdesign;

public class Usuario extends Persona{
    private String idUsuario;
    private String correo;
    private String password;
    private String perfil;
    private String localidad;

    public Usuario(String idUsuario, String correo, String password, String perfil, String localidad, String nombre, int genero, boolean activo, String numTelefonico, String edad) {
        super(nombre, genero, activo, numTelefonico, edad);
        this.idUsuario = idUsuario;
        this.correo = correo;
        this.password = password;
        this.perfil = perfil;
        this.localidad = localidad;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }
    
    
}
