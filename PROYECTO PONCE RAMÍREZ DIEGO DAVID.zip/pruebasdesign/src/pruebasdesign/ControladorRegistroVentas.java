package pruebasdesign;

import java.time.LocalDateTime;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author diego
 */
public class ControladorRegistroVentas {
    frmVentasInternal frmVentas;
    ModeloRegistroVentas registroVentas;
    private String idVentaModificar;

    public ControladorRegistroVentas(frmVentasInternal frmVentas, ModeloRegistroVentas registroVentas) {
        this.frmVentas = frmVentas;
        this.registroVentas = registroVentas;
    }
    
     public void agregarVenta(){
    LocalDateTime fecha = frmVentas.getFechaSeleccionada();
    String id = frmVentas.getId();
    int tipoVentas = frmVentas.getTipoVenta();
    int cantidad = frmVentas.getCantidad();
    Cliente cliente = frmVentas.getCliente();
    Producto producto = frmVentas.getProducto();
    double descuento = frmVentas.getDescuento();
    double subtotal = frmVentas.getSubtotal();
    double total = frmVentas.getTotal();
    boolean pagoCompleto = frmVentas.getPago();
   
    if(id.isEmpty() || tipoVentas < 0){
        mostrarError("Faltan campos por llenar");
        return;
    }
    
    if(producto == null) {
        mostrarError("Debe seleccionar un producto");
        return;
    }
    
    if(cliente == null) {
        mostrarError("Debe seleccionar un cliente");
        return;
    }
    
    if(producto.getStockActual() < cantidad) {
        mostrarError("Stock insuficiente.\n" +
                    "Stock disponible: " + producto.getStockActual() + " unidades\n" +
                    "Cantidad solicitada: " + cantidad + " unidades");
        return;
    }
    
    try {
        registroVentas.agregarVenta(fecha, id, tipoVentas, cantidad, cliente, 
                                   producto, descuento, subtotal, total, pagoCompleto);
        
        JOptionPane.showMessageDialog(null, 
            "Venta registrada exitosamente\n" +
            "Stock actualizado: " + producto.getStockActual() + " unidades restantes", 
            "Éxito", 
            JOptionPane.INFORMATION_MESSAGE);
        
        frmVentas.actualizarComboBoxes();
        
    } catch (IllegalArgumentException e) {
        mostrarError("Error: " + e.getMessage());
    } catch (Exception e) {
        mostrarError("Error al registrar la venta: " + e.getMessage());
    }
}
     
     public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
     
     public void mostrar(){
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID", "Fecha", "Tipo de Venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado de pago"}, 0
    );
    
    frmVentas.jTable1.setModel(modelo);
    
    Pila pilaVentas = registroVentas.obtenerPilaVentas();
    
    if(pilaVentas != null && !pilaVentas.estaVacia()) {
        Nodo aux = pilaVentas.getPila();
        
        while (aux != null) {
            Venta l = (Venta) aux.getValor();
            modelo.addRow(new Object[]{
               l.getId(),
               l.getFecha(),
               l.getTipoVenta(),
               l.getCantidad(),
               l.getClientes(),
               l.getProducto(),
               l.getDescuento(),
               l.getSubtotal(),
               l.getTotal(),
               l.isPagoCompleto()
            });
            
            aux = aux.getSiguiente();
        }
    }
}
     
     public void buscar(){
    String id = frmVentas.buscar();
    
    if(id.isEmpty()){
        mostrarError("Ingrese un ID para buscar");
        return;
    }
    
    Venta ventaEncontrado = registroVentas.buscar(id);
    
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID", "Fecha", "Tipo de Venta", "Cantidad", "Cliente", "Producto", "Descuento", "Subtotal", "Total", "Estado de pago"}, 0
    );
    
    if(ventaEncontrado != null){
        modelo.addRow(new Object[]{
            ventaEncontrado.getId(),
            ventaEncontrado.getFecha(),
            ventaEncontrado.getTipoVenta(),
            ventaEncontrado.getCantidad(),
            ventaEncontrado.getClientes(),
            ventaEncontrado.getProducto(),
            ventaEncontrado.getDescuento(),
            ventaEncontrado.getSubtotal(),
            ventaEncontrado.getTotal(),
            ventaEncontrado.isPagoCompleto()
        });
        
        JOptionPane.showMessageDialog(null, "Venta encontrada", 
                                    "Búsqueda exitosa", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(null, "Venta con ID " + id + " no encontrado", 
                                    "Búsqueda", JOptionPane.WARNING_MESSAGE);
    }
    
    frmVentas.jTable1.setModel(modelo);
}
     
    public void eliminar(){
    String id = frmVentas.buscar();
    
    if(id.isEmpty()){
        mostrarError("Ingrese un ID para eliminar");
        return;
    }
    
    Venta ventaEncontrado = registroVentas.eliminar(id);
    
    if(ventaEncontrado != null) {
        JOptionPane.showMessageDialog(null, "Venta eliminada exitosamente", 
                                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
        frmVentas.limpiarTabla();
    } else {
        JOptionPane.showMessageDialog(null, "Venta con ID " + id + " no encontrada", 
                                    "Error", JOptionPane.ERROR_MESSAGE);
    }
}
     
    public void buscarModificar(){
    String id = JOptionPane.showInputDialog("Ingrese el ID de la venta a modificar:");
    
    if(id == null || id.isEmpty()){
        mostrarError("Ingrese un ID para buscar");
        return;
    }
    
    Venta ventaEncontrado = registroVentas.buscar(id);
    
    if(ventaEncontrado != null){
        idVentaModificar = id;
        frmVentas.jtfIdVenta.setEditable(false);

        frmVentas.jtfIdVenta.setText(ventaEncontrado.getId());

        if(ventaEncontrado.getFecha() != null) {
            frmVentas.setFecha(ventaEncontrado.getFecha());
        }
        
        frmVentas.jcbVenta.setSelectedIndex(ventaEncontrado.getTipoVenta());
        frmVentas.jsbCantidad.setValue(ventaEncontrado.getCantidad());
        frmVentas.jcbClientes.setSelectedItem(ventaEncontrado.getClientes());
        frmVentas.jcbProducto.setSelectedItem(ventaEncontrado.getProducto());
        
        int indiceDescuento = (int) ventaEncontrado.getDescuento();
        frmVentas.jcbDescuento.setSelectedIndex(indiceDescuento);
        
        frmVentas.jlbSubtotal.setText("$" + String.format("%.2f", ventaEncontrado.getSubtotal()));
        frmVentas.jlbTotal.setText("$" + String.format("%.2f", ventaEncontrado.getTotal()));
        frmVentas.jcbPago.setSelected(ventaEncontrado.isPagoCompleto());
        
        JOptionPane.showMessageDialog(null, "Venta encontrada. Modifique los campos necesarios.");
    } else {
        mostrarError("Venta no encontrada");
        idVentaModificar = null; 
    }
}
    
     public void modificar(){
    if (idVentaModificar == null || idVentaModificar.isEmpty()) {
        mostrarError("Debe buscar una venta primero usando 'Buscar'");
        return;
    }
    
    LocalDateTime fecha = frmVentas.getFechaSeleccionada();
    String id = frmVentas.getId();
    int tipoVentas = frmVentas.getTipoVenta();
    int cantidad = frmVentas.getCantidad();
    Cliente cliente = frmVentas.getCliente();
    Producto producto = frmVentas.getProducto();
    double descuento = frmVentas.getDescuento();
    double subtotal = frmVentas.getSubtotal();
    double total = frmVentas.getTotal();
    boolean pagoCompleto = frmVentas.getPago();
   
    if(id.isEmpty() || tipoVentas < 0){
        mostrarError("Faltan campos por llenar");
        return;
    } 
    
    try {
        boolean modificado = registroVentas.modificarVenta(idVentaModificar, fecha, id, 
                                                            tipoVentas, cantidad, cliente, 
                                                            producto, descuento, subtotal, 
                                                            total, pagoCompleto);
        
        if(modificado) {
            JOptionPane.showMessageDialog(null, "Venta modificada exitosamente", 
                                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            idVentaModificar = null;
            frmVentas.jtfIdVenta.setEditable(true);
            frmVentas.limpiar();
        } else {
            mostrarError("No se pudo modificar la venta");
        }
        
    } catch (Exception e) {
        mostrarError("Error al modificar: " + e.getMessage());
    }
}
     
     
     public void limpiar(){
         frmVentas.limpiar();
     }
    
     public void limpiarTablas(){
         frmVentas.limpiarTabla();
     }
}
